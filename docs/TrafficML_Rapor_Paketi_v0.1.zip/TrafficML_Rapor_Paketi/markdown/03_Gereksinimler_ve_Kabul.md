# Gereksinimler ve Kabul Ölçütleri

Kaynak 37 FR + açıkça ayrılmış EK ve NF önerileri

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## Belge kuralı
Aşağıdaki sekiz bölüm, K01'in organizasyonunu ve FR-01–FR-37 kimliklerini korur. **“Kaynak gereksinim” cümleleri yüklenen PDF'den alınmıştır; satır sonları birleştirilmiştir.** Her maddenin altındaki kabul ölçütü, bileşen, test ve geliştirme aşaması bu paketin önerisidir; test yapılmış olduğu anlamına gelmez. [K01]

M1 ilk uçtan uca prototip; M2 geometri/kentsel elemanlar, maliyet ve veri doğrulama genişletmesi; M3 teşhis, ML ve bütünleşik değerlendirmedir. Fazlandırma, kaynak FR'lerin silinmesi değildir. 37 FR'nin tamamına ilişkin desteklenen parametreler ürün tesliminde ayrıca ilan edilmelidir.

**Terminoloji notu:** Kaynak FR-05/06/08'de “trafik yoğunluğu” adı korunmuştur. Araç/saat girdisi veri sözlüğünde akış/talep olarak tanımlanır; araç/km yoğunluğu ayrı kavramdır. İsim düzeltmesi yapılacaksa ekip onaylı revizyon gerekir.


## 1. Proje ve Bölge Yönetimi

### FR-01 — Proje Oluşturma
**Kaynak gereksinim:** Sistem, kullanıcının yeni bir trafik analiz projesi oluşturmasına izin vermelidir.

**Önerilen kabul:** Proje kaydedilir; yeniden açıldığında adı, bölge sürümü ve sahibi korunur. Yetkisiz kullanıcı proje içeriğini okuyamaz.

Bileşen: PROJECT | Aşama: M1 | Test: T-FR-01

### FR-02 — Analiz Bölgesi Seçimi
**Kaynak gereksinim:** Kullanıcı harita üzerinden analiz edilecek yol, kavşak veya bölgeyi seçebilmelidir.

**Önerilen kabul:** Seçilen analiz sınırı kaydedilir; müdahale alanı ve etki değerlendirme alanı ayrı görülebilir. Koordinat sistemi belirtilir.

Bileşen: PROJECT | Aşama: M1 | Test: T-FR-02

### FR-03 — Mevcut Yol Verisinin Alınması
**Kaynak gereksinim:** Sistem seçilen bölgenin mevcut yol geometrisini harita verilerinden alabilmelidir.

**Önerilen kabul:** İçe aktarma kaynağı, tarihi ve ağ sürümü tutulur. Eksik şerit/sinyal bilgisi doğrulanmış gibi işaretlenmez.

Bileşen: PROJECT | Aşama: M1 | Test: T-FR-03

### FR-04 — Yol Parametrelerinin Düzenlenmesi
**Kaynak gereksinim:** Kullanıcı şerit sayısı, şerit genişliği, yol yönü, hız limiti ve kavşak yapısı gibi parametreleri düzenleyebilmelidir.

**Önerilen kabul:** Değişiklik yeni tasarım sürümü oluşturur. Geçersiz genişlik, kopuk bağlantı veya hatalı izin durumu simülasyon öncesi bildirilir.

Bileşen: PROJECT | Aşama: M1 | Test: T-FR-04

## 2. Trafik Verileri

### FR-05 — Trafik Yoğunluğu Girişi
**Kaynak gereksinim:** Kullanıcı bölgeye ait araç/saat trafik yoğunluğunu sisteme girebilmelidir.

**Önerilen kabul:** Araç/saat girdisinin birimi ve hangi zaman dilimine ait olduğu saklanır. Negatif değer reddedilir; eksik değer sıfıra çevrilmez.

Bileşen: DATA | Aşama: M1 | Test: T-FR-05

### FR-06 — Trafik Dağılımı Tanımlama
**Kaynak gereksinim:** Kullanıcı farklı yönlerden gelen araç yoğunluklarını tanımlayabilmelidir.

**Önerilen kabul:** Giriş kolları ve dönüş hareketleri ayrılır. Oran kullanılıyorsa toplam ve akış korunumu denetlenir; varsayılan oranlar etiketlenir.

Bileşen: DATA | Aşama: M1 | Test: T-FR-06

### FR-07 — Araç Türlerinin Tanımlanması
**Kaynak gereksinim:** Sistem otomobil, otobüs ve ağır vasıta gibi farklı araç türlerinin oranlarını desteklemelidir.

**Önerilen kabul:** Araç sınıfları kaydedilir; oran toplamı doğrulanır. Ağda izinli olmayan araç sınıfı sessizce düşürülmez.

Bileşen: DATA | Aşama: M1 | Test: T-FR-07

### FR-08 — Farklı Trafik Senaryoları
**Kaynak gereksinim:** Kullanıcı düşük, normal ve yoğun trafik gibi farklı trafik seviyelerini test edebilmelidir.

**Önerilen kabul:** Düşük/normal/yoğun adlarının yanında sayısal talep profili veya çarpanı görünür; her biri sürümlü bir demand_id alır.

Bileşen: DATA | Aşama: M1 | Test: T-FR-08

## 3. Yol Tasarımı ve Belediye Düzenlemeleri

### FR-09 — Alternatif Yol Tasarımı Oluşturma
**Kaynak gereksinim:** Sistem mevcut yol için alternatif yol düzenlemelerinin oluşturulmasına izin vermelidir. Alternatifler şerit ekleme/çıkarma, dönüş şeridi, kavşak düzenleme, döner kavşak ve sinyalizasyon değişikliklerini içerebilir.

**Önerilen kabul:** Pilot fiziksel şablon ile sinyal alternatifi ayrı oluşturulur. Seçilen şablon geometrisi ve bağlantıları gerçekten değiştirir; diğer FR-09 aileleri sonraki genişletmede sınanır.

Bileşen: DESIGN | Aşama: M1/M2 | Test: T-FR-09

### FR-10 — Refüj Ekleme
**Kaynak gereksinim:** Kullanıcı yola orta refüj ekleyebilmeli ve genişliğini değiştirebilmelidir.

**Önerilen kabul:** Refüj genişliği kullanılabilir kesite dahil edilir. Şerit ve kaldırımla çakışma varsa alternatif uygun bulunmaz; metraj ve 3D güncellenir.

Bileşen: DESIGN | Aşama: M2 | Test: T-FR-10

### FR-11 — Ağaçlandırma
**Kaynak gereksinim:** Kullanıcı yol kenarı veya refüj için ağaçlandırma seçeneği ekleyebilmelidir.

**Önerilen kabul:** Ağaç sayısı/yerleşimi ve maliyet kalemi değişir. Yalnızca görsel ağaç eklenmesi, trafik performansına yapay kazanç yazmaz.

Bileşen: DESIGN | Aşama: M2 | Test: T-FR-11

### FR-12 — Bisiklet Yolu
**Kaynak gereksinim:** Sistem yol tasarımına bisiklet yolu eklenmesini desteklemelidir.

**Önerilen kabul:** Bisiklet şeridi geometrisi, uzunluğu ve bağlantıları kaydedilir. Dinamik bisiklet etkisi ancak talep/model etkinse sonuçlarda gösterilir.

Bileşen: DESIGN | Aşama: M2 | Test: T-FR-12

### FR-13 — Yaya Altyapısı
**Kaynak gereksinim:** Kullanıcı kaldırım ve yaya geçidi gibi yaya altyapısı düzenlemeleri oluşturabilmelidir.

**Önerilen kabul:** Kaldırım ve geçit geometrisi korunur; yaya bağlantıları kopmaz. Yaya talebi yoksa yaya gecikmesi veya güvenlik skoru hesaplanmış gibi gösterilmez.

Bileşen: DESIGN | Aşama: M2 | Test: T-FR-13

### FR-14 — Toplu Taşıma Düzenlemeleri
**Kaynak gereksinim:** Sistem otobüs durağı gibi toplu taşıma elemanlarının yol tasarımına eklenmesine izin vermelidir.

**Önerilen kabul:** Durak konumu, hizmet veren hat/araç ve duruş davranışı ayrı alanlardır. Görsel durak ile aktif simülasyon durağı ayırt edilir.

Bileşen: DESIGN | Aşama: M2 | Test: T-FR-14

## 4. Trafik Simülasyonu

### FR-15 — Trafik Simülasyonu Çalıştırma
**Kaynak gereksinim:** Sistem oluşturulan yol tasarımını belirlenen trafik koşulları altında simüle edebilmelidir.

**Önerilen kabul:** Geçerli girdilerden run_id oluşturulur; işin durumu ve logları izlenir. Başarısız koşu tamamlanmış gibi raporlanmaz.

Bileşen: SIM | Aşama: M1 | Test: T-FR-15

### FR-16 — Alternatif Tasarımların Simülasyonu
**Kaynak gereksinim:** Sistem birden fazla yol tasarımını aynı trafik koşulları altında ayrı ayrı simüle edebilmelidir.

**Önerilen kabul:** Adaylar ortak değerlendirme protokolünü kullanır. Geometri değişiminde ağ farklı olabilir; dış talep, dönem, davranış varsayımları ve eşleme kaydı korunur.

Bileşen: SIM | Aşama: M1 | Test: T-FR-16

### FR-17 — Trafik Performans Metrikleri
**Kaynak gereksinim:** Sistem her simülasyon sonucunda en az ortalama bekleme süresi, ortalama hız, kuyruk uzunluğu, seyahat süresi ve geçen araç sayısını hesaplamalıdır.

**Önerilen kabul:** Beş kaynak ölçüt birim ve kapsamıyla hesaplanır. Bitmemiş/ağa giremeyen araçlar ayrıca görünür; geçen araç sayısı kapasite diye etiketlenmez.

Bileşen: SIM | Aşama: M1 | Test: T-FR-17

### FR-18 — Farklı Zaman/Yoğunluk Koşulları
**Kaynak gereksinim:** Kullanıcı aynı tasarımı farklı trafik yoğunluklarında çalıştırabilmelidir.

**Önerilen kabul:** Tek tasarım farklı demand_id değerlerinde çalıştırılır. Sonuç ekranı hangi yoğunluk profilinin seçildiğini gösterir.

Bileşen: SIM | Aşama: M1 | Test: T-FR-18

## 5. Makine Öğrenmesi ve Optimizasyon

### FR-19 — Simülasyon Verisi Toplama
**Kaynak gereksinim:** Sistem gerçekleştirilen simülasyonların giriş parametrelerini ve sonuçlarını veri seti olarak kaydedebilmelidir.

**Önerilen kabul:** Girdi/çıktı manifesti, ağ/talep sürümü, seed, yazılım sürümü ve hata bayrakları veri setine aktarılır. Aynı deneyin kopyası sessizce çoğaltılmaz.

Bileşen: ML | Aşama: M1 | Test: T-FR-19

### FR-20 — Performans Tahmini
**Kaynak gereksinim:** ML modeli belirli yol ve trafik koşullarında alternatif tasarımların beklenen trafik performansını tahmin edebilmelidir.

**Önerilen kabul:** Model alternatif performansını tahmin eder; model_id ve eğitim kapsamı görünür. Grup ayrımlı test ve basit referans karşılaştırması olmadan doğrulanmış etiketi almaz.

Bileşen: ML | Aşama: M3 | Test: T-FR-20

### FR-21 — Tasarım Alternatifleri Üretme/Seçme
**Kaynak gereksinim:** Sistem mevcut yol özelliklerine göre uygulanabilir tasarım alternatiflerini belirleyebilmelidir.

**Önerilen kabul:** Kısıt dosyasına aykırı seçenekler elenir veya inceleme bekliyor durumuna alınır. Bilinmeyen saha bilgisi uygulanabilirlik onayı sayılmaz.

Bileşen: OPT | Aşama: M3 | Test: T-FR-21

### FR-22 — Optimizasyon
**Kaynak gereksinim:** Sistem trafik performansı, maliyet ve kentsel düzenleme kriterlerini dikkate alarak farklı çözüm alternatiflerini karşılaştırabilmelidir.

**Önerilen kabul:** Maliyet, trafik ve kentsel ölçütler ayrı görünür. Kullanılan tercih ağırlıkları/kısıtlar kaydedilir; sonuç yalnızca denenmiş adaylar için yorumlanır.

Bileşen: OPT | Aşama: M3 | Test: T-FR-22

## 6. Maliyet Analizi

### FR-23 — Birim Maliyet Yönetimi
**Kaynak gereksinim:** Sistem asfalt, yol genişletme, refüj, ağaçlandırma, bisiklet yolu ve kaldırım gibi müdahaleler için birim maliyetler saklayabilmelidir.

**Önerilen kabul:** Her birim fiyatın kaynağı, poz/tanımı, birimi, para birimi, geçerlilik tarihi ve kapsadığı işler kaydedilir.

Bileşen: COST | Aşama: M2 | Test: T-FR-23

### FR-24 — Tahmini Proje Maliyeti
**Kaynak gereksinim:** Sistem oluşturulan her tasarım için yaklaşık uygulama maliyetini hesaplayabilmelidir.

**Önerilen kabul:** Miktar × birim fiyat kalemleri denetlenebilir. Eksik kalem sıfır maliyet sayılmaz; yaklaşık hesap ile uygulama teklifi ayrılır.

Bileşen: COST | Aşama: M2 | Test: T-FR-24

### FR-25 — Bütçe Tanımlama
**Kaynak gereksinim:** Kullanıcı proje için maksimum bütçe belirleyebilmelidir.

**Önerilen kabul:** Bütçe para birimi ve kapsam tarihiyle kaydedilir; negatif bütçe reddedilir. Vergi/dahil olmayan kalemler görünür.

Bileşen: COST | Aşama: M2 | Test: T-FR-25

### FR-26 — Bütçeye Göre Alternatif Filtreleme
**Kaynak gereksinim:** Sistem belirlenen bütçeyi aşan ve bütçeye uygun alternatifleri gösterebilmelidir.

**Önerilen kabul:** Aday uygun/aşıyor/değerlendirilemiyor olarak sınıflanır. Eksik maliyet kalemli aday otomatik bütçeye uygun sayılmaz.

Bileşen: COST | Aşama: M2 | Test: T-FR-26

## 7. 3D Görselleştirme

### FR-27 — 3D Yol Görselleştirme
**Kaynak gereksinim:** Sistem seçilen yol/kavşak bölgesini 3D perspektif görünümde gösterebilmelidir.

**Önerilen kabul:** Pilot ağının yol ve kavşak modeli ilgili tasarım sürümünden üretilir. 3D gösterimde kaynak/model durumu görünür.

Bileşen: VIEW3D | Aşama: M1 | Test: T-FR-27

### FR-28 — 3D Trafik Animasyonu
**Kaynak gereksinim:** Simülasyondaki araç hareketleri 3D ortamda görselleştirilmelidir.

**Önerilen kabul:** Araç kimliği, konumu ve zaman bilgisi aynı run_id kaydından gelir. Rastgele dekoratif araç animasyonu sonuç olarak kullanılmaz.

Bileşen: VIEW3D | Aşama: M1 | Test: T-FR-28

### FR-29 — Belediye Elemanlarının Görselleştirilmesi
**Kaynak gereksinim:** Ağaç, refüj, bisiklet yolu, kaldırım, yaya geçidi, trafik ışığı ve durak gibi elemanlar 3D ortamda gösterilebilmelidir.

**Önerilen kabul:** Her eleman aynı design_id altında listelenir. Görsel/işlevsel eleman ayrımı; metraj ve model kapsamıyla tutarlıdır.

Bileşen: VIEW3D | Aşama: M2 | Test: T-FR-29

### FR-30 — Kamera Kontrolü
**Kaynak gereksinim:** Kullanıcı 3D ortamda yakınlaştırma, uzaklaştırma, döndürme ve kaydırma yapabilmelidir.

**Önerilen kabul:** Yakınlaşma, uzaklaşma, dönüş ve kaydırma çalışır; kullanıcı başlangıç kamera konumuna dönebilir.

Bileşen: VIEW3D | Aşama: M1 | Test: T-FR-30

### FR-31 — Simülasyon Kontrolü
**Kaynak gereksinim:** Kullanıcı simülasyonu başlatabilmeli, durdurabilmeli ve simülasyon hızını değiştirebilmelidir.

**Önerilen kabul:** Hesaplama başlat/iptal ile kayıtlı tekrar oynat/duraklat ayrı kontrollerdir. Oynatma hızını değiştirmek hesaplanmış ölçütleri değiştirmez.

Bileşen: VIEW3D | Aşama: M1 | Test: T-FR-31

### FR-32 — Tasarım Değişikliklerinin Görselleştirilmesi
**Kaynak gereksinim:** Kullanıcı farklı senaryolar arasında geçiş yaptığında 3D yol modeli ilgili tasarıma göre güncellenmelidir.

**Önerilen kabul:** Senaryo değiştiğinde ağ, elemanlar ve uygun araç tekrarları birlikte değişir. Eski tasarımın sonuçları yeni sürüme taşınmaz.

Bileşen: VIEW3D | Aşama: M1 | Test: T-FR-32

## 8. Karşılaştırma ve Raporlama

### FR-33 — Senaryo Karşılaştırması
**Kaynak gereksinim:** Kullanıcı mevcut durum ile alternatif tasarımları yan yana karşılaştırabilmelidir.

**Önerilen kabul:** Mevcut düzen ve adaylar aynı değerlendirme paketinde yan yana görünür; farklı değerlendirme koşulları için uyarı verilir.

Bileşen: REPORT | Aşama: M1 | Test: T-FR-33

### FR-34 — Performans Karşılaştırması
**Kaynak gereksinim:** Sistem alternatiflerin trafik performansındaki yüzde değişimleri gösterebilmelidir.

**Önerilen kabul:** Yüzde hesabında referans, yön ve payda görünür. Referans sıfır olduğunda yüzde yerine mutlak fark ve hesaplanamaz etiketi kullanılır.

Bileşen: REPORT | Aşama: M1 | Test: T-FR-34

### FR-35 — Maliyet/Performans Karşılaştırması
**Kaynak gereksinim:** Sistem her alternatifin tahmini maliyetini ve sağladığı performans değişimini birlikte gösterebilmelidir.

**Önerilen kabul:** Yaklaşık maliyet, trafik kazanımı ve olumsuz yan etkiler birlikte sunulur. Eksik maliyet bilgisi gizlenmez.

Bileşen: REPORT | Aşama: M2 | Test: T-FR-35

### FR-36 — Çevresel/Kentsel Göstergeler
**Kaynak gereksinim:** Sistem ağaç sayısı, oluşturulan yeşil alan ve bisiklet yolu uzunluğu gibi ölçülebilir kentsel göstergeleri sunabilmelidir.

**Önerilen kabul:** Ağaç sayısı, net yeşil alan değişimi ve bisiklet yolu uzunluğu açık birimlerle verilir. Yaşam kalitesi veya kaza skoru bu maddeden türetilmez.

Bileşen: REPORT | Aşama: M2 | Test: T-FR-36

### FR-37 — Sonuç Raporu
**Kaynak gereksinim:** Sistem analiz sonuçlarını belediyenin inceleyebileceği bir rapor halinde oluşturabilmelidir.

**Önerilen kabul:** Rapor kaynakları, manifest kimliklerini, referans koşullarını, sonuçları, yan etkileri, belirsizlikleri ve kapsam dışı etkileri içerir.

Bileşen: REPORT | Aşama: M1/M3 | Test: T-FR-37


## 9. Önerilen yeni gereksinimler — EK serisi
Bu maddeler mevcut PDF'de bu açıklıkta yer almayan eklerdir. Yeni bir FR numarasına dönüştürülmeden önce ekip/danışman onayı gerekir. Kaynak 37 FR içine sessizce dahil edilmemiştir.

| Kimlik | Önerilen gereksinim | Kabul / test bağlantısı |
|---|---|---|
| EK-01 | Zaman damgalı saha gözlemleri içe alınmalıdır. | Kaynak, zaman, birim, konum ve ölçüm türü olmayan kayıt uyarılır. T-EK-01 / DATA |
| EK-02 | Ölçüm, kullanıcı varsayımı, kestirim ve simülasyon ayrılmalıdır. | Ekranda ve raporda her değerin türü bulunur; eksik veri sıfır yapılmaz. T-EK-02 / DATA |
| EK-03 | Kalibrasyon ve ayrı veriyle doğrulama kaydedilmelidir. | Veri bölümleri, hata ölçütleri ve geçerlilik alanı kaydedilir. T-EK-03 / MODEL |
| EK-04 | Sistem olası tıkanıklık kaynaklarını dayanaklarıyla gösterebilmelidir. | Kanıt, karşı açıklama ve eksik veri bulunur; kararsız kalabilme desteklenir. T-EK-04 / DIAG |
| EK-05 | Müdahalenin komşu bağlantılardaki etkileri izlenmelidir. | En olumsuz etkilenen yaklaşım ve ağ sınırına taşan kuyruk görünür. T-EK-05 / REPORT |
| EK-06 | Mekânsal/işletim kısıtları aday üretiminden önce kontrol edilmelidir. | Bilinmeyen koşul uygunluk onayı değildir; ihlalli aday engellenir. T-EK-06 / DESIGN |
| EK-07 | Deneyler sürümlü ve tekrar üretilebilir olmalıdır. | Girdi hash'i, seed, sürümler ve protokol rapordan bulunabilir. T-EK-07 / SIM |
| EK-08 | Tekrar ve talep belirsizliği ayrı raporlanmalıdır. | Seed aralığı saha güven aralığı olarak adlandırılmaz. T-EK-08 / EVAL |
| EK-09 | ML eğitim kapsamı dışındaki girdiler belirlenmelidir. | Yeni aile/taşkın parametre için uyarı veya doğrudan simülasyon yolu vardır. T-EK-09 / ML |
| EK-10 | 3D, ölçütler ve maliyet aynı tasarım sürümünü kullanmalıdır. | Sürüm uyuşmazlığı gösterimi durdurur; yeni tasarım sonuçları geçersizleştirir. T-EK-10 / VIEW3D |
| EK-11 | Referans gelecekle müdahale geleceği uyumlu protokolle karşılaştırılmalıdır. | Karşılaştırma anahtarı uyuşmuyorsa varsayılan yüzde hesabı engellenir. T-EK-11 / EVAL |
| EK-12 | Kullanıcı eylemleri ve deney onayları izlenebilmelidir. | Değişiklik, kaynak ve onay sahibi denetim kaydında görünür. T-EK-12 / PROJECT |

## 10. Fonksiyonel olmayan gereksinimler — öneri
| Kimlik | Ölçülebilir tanım | Doğrulama |
|---|---|---|
| NF-01 | Aynı sürüm, girdi ve seed için tekrar üretim | Sayısal tolerans ve ortam birlikte tanımlanır; altın deneyle kontrol edilir. |
| NF-02 | Projeler arası erişim ayrımı | Başka projenin run_id'siyle veri/rapor okuma girişimi reddedilir. |
| NF-03 | Girdi ve kaynak sınırlandırma | Ham komut enjeksiyonu, uygunsuz XML ve sınırsız iş üretimi test edilir. |
| NF-04 | Hata ve iptalde veri tutarlılığı | Worker kesilmesi, yeniden deneme ve çift istek tekil iş kaydıyla yönetilir. |
| NF-05 | Performans bütçesi | Donanım, ağ, araç sayısı ve çıktı ayrıntısı belirtilerek P50/P95 süre ve RAM ölçülür; hedef benchmark sonrası sabitlenir. |
| NF-06 | Görsel erişilebilirlik | İyileşme yalnız renkle anlatılmaz; metin, işaret, birim ve klavye erişimi denetlenir. |
| NF-07 | Veri/varlık lisans kaydı | Her dış kaynağın atfı, kullanım kapsamı ve saklama koşulu kayıtlıdır. |
| NF-08 | Geri yükleme ve kaynak izleme | Örnek proje yedekten geri alınır; model ve rapor manifest hash'leri doğrulanır. |

## 11. Kullanım senaryoları ve başarısızlık yolları
**UC-01 — Tasarımı dene:** Analist bölgeyi ve talebi seçer, referans düzeni kilitler, bir fiziksel ve bir sinyal alternatifi oluşturur. Kısıt kontrolü sonrasında koşuları başlatır; sonuçlar, maliyet ve 3D tekrar aynı sürüm üzerinden açılır. Ana eşleme: FR-01–18, FR-23–37, EK-06/07/10/11.

**UC-02 — Sorunu incele:** Kullanıcı veri yeterliliği ekranından ilerler. Hipotez kartında kaynak adayını, zaman çizelgesini ve eksik ölçümleri görür. Sistem ilgili şablonları önerir; kullanıcı bunlardan bağımsız başka aday da ekleyebilir. Ana eşleme: EK-01–05, FR-21/22/33–37.

**UC-03 — Hızlı ön değerlendirme:** Kullanıcı desteklenen tasarım ailesi için ML ön tahmini alır. Eğitim dışı örnekte uyarı verilir. Seçilen aday tekrar simülasyona girer; ML ön tahmini nihai doğrulanmış sonuç etiketi taşımaz. Ana eşleme: FR-19–22, EK-08/09.

**Başarısızlık davranışları:** Veri yetmezse sentetik/varsayımsal çalışma önerisi açık etiketle sunulur; kullanıcı sessizce gerçek veri moduna geçirilmez. Simülasyon çökerse rapor tamamlanmış görünmez. Uygun aday yoksa “tanımlı adaylar içinde uygun seçenek bulunamadı” denir. Sonuçlar yakınsa tek bir kesin kazanan ilan edilmez.

## 12. İzlenebilirlik ve değişiklik yönetimi
FR/EK/NF kimliği → bileşen → kabul ölçütü → test → deney/rapor kaydı bağlantısı kullanılacaktır. Makinece okunabilir 37 FR dökümü ve önerilen kabul ölçütleri eklerdeki JSON dosyasındadır. Durumlar planlandı/geliştirildi/test edildi/kabul edildi olarak ayrı ilerler; bu pakette tüm testler planlanmıştır, gerçekleştirilmemiştir.

Bir kaynak gereksinim değiştirildiğinde özgün metin, değişiklik gerekçesi, karar sahibi ve etkilenen testler korunmalıdır. Görsel taslaktaki kaza oranı ve yaşam kalitesi kartları, FR onayı yerine kullanılamaz.

## Kaynak bağlantıları


