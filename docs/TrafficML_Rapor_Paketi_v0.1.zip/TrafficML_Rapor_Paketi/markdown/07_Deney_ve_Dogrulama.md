# Deney, Doğrulama ve Başarı Ölçütleri

Karşılaştırılabilir koşullar, sınanabilir iddialar ve tekrar üretilebilir sonuçlar

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Belgenin durumu ve değerlendirme katmanları
Bu belge bir deney protokolüdür. Buradaki testler henüz çalıştırılmamış; TrafficML için doğruluk, hızlanma, trafik faydası veya maliyet tasarrufu ölçülmemiştir. Başarı eşikleri, geliştirme testleri ile nihai değerlendirme birbirine karıştırılmadan belirlenecektir.

| Katman | Sınanacak iddia | Kanıt türü |
|---|---|---|
| Yazılım doğrulaması | Hesaplamalar, veri dönüşümleri ve iş durumları tanımlandığı gibi çalışıyor. | Birim, entegrasyon, negatif durum ve uçtan uca testler |
| Trafik modeli | Pilot model gözlenen trafik davranışını yeterince temsil ediyor. | Kalibrasyonda kullanılmamış gün/dönem/ölçüm karşılaştırması |
| Sorun analizi | Sistem desteklenebilir hipotezleri buluyor ve belirsizliği saklamıyor. | Nedeni kontrollü sentetik örnekler; varsa bağımsız saha/uzman incelemesi |
| ML ön tahmini | Model, belirlenen tasarım alanında simülatör sonuçlarını yararlı biçimde yaklaştırıyor. | Tasarım grupları ayrılmış test, hata ve aday sıralama kaybı |
| Müdahale değerlendirmesi | Öneri, tanımlı koşullarda referansa kıyasla fayda/yan etki üretiyor. | Eşleştirilmiş deney tekrarları ve talep duyarlılığı |
| Kullanım ve sunum | Uzman hangi veriye ve sonuca baktığını doğru anlayabiliyor. | Görev temelli kullanıcı oturumu ve model-görünüm tutarlılığı testi |

Bu katmanlar birbirinin yerine geçmez. ML'nin simülatöre yakın sonucu, simülatörün sahaya yakın olduğunu kanıtlamaz. Sentetik neden etiketleri, gerçek sahada nedensellik kanıtı sayılmaz. Gözlemle kalibrasyon gereği ve tekrarlı alternatif analizi için temel çerçeve FHWA'dan alınmış, aşağıdaki uygulama ayrıntıları projeye uyarlanmıştır. [R03] [R04]

## 2. Referans ve alternatif için iki ayrı deney protokolü
### 2.1. İşletim değişikliği: uyumlu ağ üzerinde sinyal müdahalesi
Ağ topolojisi değişmiyorsa aynı başlangıç girdileriyle koşular üretilebilir. Uyumlu bir durum kaydı üzerinden dallanma da seçenek olabilir. Ancak snapshot tek başına tam deney değildir: gelecekteki araç talebi, yazılım/ayar sürümleri ve rastgelelik durumu ayrı yönetilir. SUMO'nun durum yükleme belgesi aynı girdi dosyalarını tavsiye eder; RNG'nin varsayılan olarak kaydedilmediğini ve bazı iç durumların eksik olduğunu belirtir. Bu nedenle tekrar eşitliği varsayılmak yerine test edilir. [R11] [R12]

Referans, sahadaki mevcut kontrolün makul temsilidir. Mevcut sistem uyarlanabilir ise karşılaştırma onu hesaba katmalıdır. Öneriyi daha iyi göstermek için referansa bilerek kötü bir sinyal planı konulmaz. Müdahalenin devreye giriş zamanı ve geçiş etkilerinin ölçüme dahil olup olmadığı önceden tanımlanır.

### 2.2. Fiziksel değişiklik: farklı ağlarda ortak dış talep
Şerit ekleme/çıkarma, dönüş şeridi veya kavşak değişiminde eski aracın şerit kimliği ve konumu yeni ağda geçerli olmayabilir. Bu nedenle ana protokol, eski ağın snapshot'ını değişmiş ağa zorla yüklemek değildir. Her alternatif kendi doğrulanmış ağında, ortak başlangıç-varış talebi ve planlanan hareket saatlerinden türetilen girdilerle çalıştırılır. Her ağ kendi ısınma döneminden geçer; karşılaştırma aynı değerlendirme penceresinde yapılır.

Ortak tutulan şey, dışarıdan bölgeye gelmek isteyen talep ve deney koşullarıdır. Yeni ağın izin verdiği güzergâhlar farklılaşabilir. Kaldırılmış bir yoldan geçen eski rotayı zorunlu kılmak yerine yönlendirme varsayımı kaydedilir. Sabit rota ve yeniden yönlendirme ayrı duyarlılık deneyleri olabilir.

Bu yöntem bir planlama karşılaştırmasıdır; araçların iki farklı fiziksel ağda aynı koordinatta bulunması iddiası değildir. K02'deki genel “aynı başlangıç durumu” önerisi bu ayrımla sınırlandırılmıştır; kaynak metin değiştirilmemiştir. Ağ sürümlerinin farklı olması karşılaştırmayı tek başına geçersiz yapmaz. Ortak dış talep, dönem, metrik tanımı ve protokol uyumu kontrol edilir. [K02, bölüm 7] [R09] [R11]

## 3. Deney tekrarları, seçim yanlılığı ve belirsizlik
Her koşu için seed, ağ/talep/kontrol sürümleri, yazılım ortamı, başlangıç, ısınma, ölçüm ve bitiş zamanı manifestte tutulur. Referans ve alternatif, mümkün olduğunca eşleştirilmiş talep örnekleriyle değerlendirilir. Aynı seed, değişen ağlarda bütün rastlantısal olayların birebir aynı olacağını garanti eden bir iddia olarak kullanılmaz.

Ön denemelerden çalışma süresi ve koşular arası değişkenlik ölçülür. Nihai tekrar sayısı ve gerekli hassasiyet bu bilgiyle, son test sonuçları görülmeden belirlenir. Tek tek araçlar veya ardışık saniyeler bağımsız deney tekrarı gibi sayılmaz. Rastgele sürüş davranışının değişkenliği, talep tahmininin belirsizliği ve modelin yapısal hatası ayrı raporlanır.

Optimizasyonda seçilen adaylar, yalnızca onları seçtiren koşularla övülmez; ayrılmış değerlendirme seed/talep örnekleriyle tekrar sınanır. Çok aday denenmiş olması ve hangi adayların rapor dışında kaldığı deney geçmişinde görünür. Ortalama etki yanında dağılım, olumsuz tekrarlar ve ilgili aralıklar gösterilir. Bu aralıklar, tanımlı simülasyon varsayımları altındadır; otomatik olarak gerçek saha için güven düzeyi anlamına gelmez. [R04]

## 4. Metrik sözlüğü ve hesaplama sınırları
| Metrik | Önerilen tanım / birim | Gerekli uyarı |
|---|---|---|
| Ortalama bekleme | Seçili araç grubu için motorun waitingTime alanı; sn/araç | Planlı duruşlar ve durma eşiği çıktı şemasına göre belirtilir. Bekleme, toplam gecikmeyle özdeş değildir. |
| Seyahat süresi | Başlangıç-varışını tamamlayan araçlarda duration; sn | Tamamlamayanların sayısı ve artık bekleme ayrıca gösterilir. |
| Ortalama hız | Seçili penceredeki toplam araç mesafesi / toplam araç zamanı; km/saat | Kesim ortalamalarının ağırlıksız ortalaması kullanılmaz; mekânsal kapsam sabittir. |
| Kuyruk | Tanımlı dedektör/şerit kapsamındaki kuyruk uzunluğu; m ve/veya araç | Dedektör alanı, durma ve sıkışıklık eşikleri, örnekleme aralığı belirtilir. |
| Geçen araç sayısı | Tanımlı çıkış/ölçüm kesitini geçen araç; araç/dönem | Kapasite değil, gözlenen simülasyon geçişidir. |
| Tamamlama ve giriş | Sunulan, ağa girebilen, tamamlayan ve tamamlamayan araçlar | Daha az aracın ağa girmesi başarı gibi görünmemelidir. |
| Ağda geçirilen toplam süre | Ağ içindeki ve girişte bekleyen araç sayısının zamana göre toplamı; araç-saat | Sonlu pencere nedeniyle kalan araçların etkisi ayrıca raporlanır. |
| Zaman kaybı | Motorun timeLoss ve gerektiğinde departDelay alanları, ayrı ve açıklanmış | Serbest akışa göre kayıp tanımı ve alanların kapsamı açık olmalıdır. |
| Yan yol etkisi | Her yaklaşım/kesim için referansa göre bekleme, kuyruk ve geçiş farkı | Bölge ortalaması kötüleşen küçük bir kolu gizlememelidir. |
| Kentsel / maliyet | Metraj tabanlı ağaç, alan, uzunluk ve para birimli maliyet | Ölçülmeyen yaşam kalitesi, kaza riski veya emisyon skoru eklenmez. |

TripInfo varsayılan olarak tamamlanan yolculuklarda yazıldığı için bitmemiş yolculuklar için uygun çıktı seçeneği ve ayrıca giriş kuyruğu takibi gerekir. Kuyruk değerlendirmesi E2 gibi tanımlı ölçüm alanlarından yapılabilir. FR-17'nin isimleri korunmuş, bu tabloyla uygulama karşılıkları belirginleştirilmiştir. [K01, FR-17] [R13] [R14]

Önerilen pencere içi ağ yükü hesabı: toplam araç-saat = Σ[(ağdaki araç + ağa girmeyi bekleyen araç) × Δt] / 3600. Bu ölçüt tek başına yeterli değildir; her senaryoda aynı sunulan talep, kalan araçlar ve varsa rota mesafesi değişimleri birlikte incelenir. Teleport, araç kaldırma, geçersiz rota veya beklenmedik sonlandırma kalite bayrağı oluşturur; bunlar açıklanmadan sonuç onaylanmaz.

## 5. Yüzdesel değişim ve raporlama
Azalması tercih edilen bir metrikte iyileşme = 100 × (referans − alternatif) / referans. Artması tercih edilen bir metrikte iyileşme = 100 × (alternatif − referans) / referans. Referans sıfırsa yüzde hesaplanmaz; mutlak fark verilir. Negatif sonuç kötüleşmedir. Tercih yönü olmayan metrikte “değişim” yazılır, otomatik iyi/kötü rengi kullanılmaz.

Deney çiftleri için fark Δᵢ = alternatifᵢ − referansᵢ olarak kaydedilir. Ortalama fark ile uygun istatistiksel aralık aynı eşleştirilmiş örnekler üzerinden hesaplanır. Toplam gecikme, tek bir kavşağın ortalama hızı ve başka bir kavşağın kuyruğu tek bir belirsiz “trafik iyileşme yüzdesi”ne çevrilmez. Kullanıcı ağırlıklı bir puan seçerse ham ölçütler ve ağırlıklar görünür kalır. [K02, bölüm 7]

## 6. Planlanan deney matrisi
| Deney | Düzen ve karşılaştırma | Başlıca bağlı gereksinim |
|---|---|---|
| E01 Ağ doğrulaması | Yön, şerit, dönüş, sinyal ve sınır kontrolü; geçersiz bağlantı negatif testi | FR-03/04/09, EK-06 |
| E02 Kalibrasyon | Sayım, seyahat ve kuyruk zaman serileri; ayrı gün/dönem doğrulaması | EK-01/03, FR-17 |
| E03 Hipotez testi | Bilinen sentetik kaynak, karıştırıcı kaynak ve yetersiz veri örnekleri | EK-04/05 |
| E04 Alternatif etkisi | Referans + sinyal + fiziksel + birleşik aday; düşük/normal/yüksek talep | FR-08/15/16/18/22/33/34 |
| E05 ML katkısı | Basit karşılaştırmalar, grup ayrımlı test, yeni tasarım/demand ve OOD | FR-19/20/21, EK-09 |
| E06 Maliyet | Bilinen metraj, farklı birimler, eksik fiyat, bütçe sınırı | FR-23/24/25/26/35 |
| E07 Görünüm tutarlılığı | Sabit zamanlarda FCD konumu, şerit sürümü, senaryo geçişi | FR-27–32, EK-10 |
| E08 Rapor ve hata | Sıfır referans, bitmeyen yolculuk, başarısız iş, eski sonuç, lisans notu | FR-37, EK-07/08/12, NF-04/07 |
| E09 Kullanıcı görevi | Bir adayın gerekçesini, yan etkisini ve veri sınırını açıklayabilme | FR-33/35/37, NF-06 |

ML testinde aynı tasarımın farklı seed tekrarları eğitim ve test taraflarına bölünmez. Aday havuzu büyürken yeni geometrileri hiç görmeyen ayrı bir genelleme testi tutulur. Hata (MAE/RMSE) yanında yanlış aday seçmenin maliyeti ve kritik yan etkiyi kaçırma incelenir. Gruplu veri bölme için resmî GroupKFold yaklaşımı kullanılabilir; bölme planı uygulamaya özel tanımlanmalıdır. [R35]

## 7. Kabul eşikleri ve sonuç kaydı
Her ölçüt için eşik; pilotun veri kalitesi, kullanım amacı ve başlangıç değişkenliği görüldükten sonra gerekçelendirilir. Bu belgede genel geçer “%95 doğruluk” veya “en az %30 trafik kazancı” ilan edilmemiştir. Trafiği iyileştiren aday bulunmaması, yöntem dürüstçe bunu raporluyorsa yazılım testi açısından otomatik başarısızlık değildir.

Bir deney kaydı şu alanları taşır: deney kimliği, iddia, gereksinim kimlikleri, veri/ağ sürümleri, kurulum, kabul koşulu, çalıştırma durumu, ölçüm sonucu, artefakt adresleri, değerlendiren kişi ve sınırlılıklar. Başlangıçta durum “planlandı”, sonuç “çalıştırılmadı”dır; boş ölçüm sıfırla doldurulmaz.

**Yayınlama kapısı:** Girdi manifesti tamam, kalite bayrakları incelenmiş, doğru protokol kullanılmış, negatif/olumsuz sonuçlar görünür, yeni ölçülmüş gibi sunulan temsili sayı yok. Saha uygulaması ve gerçek etki değerlendirmesi ayrı bir sonraki süreçtir.

## Kaynak bağlantıları

[R03]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter5.htm
[R04]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter6.htm
[R09]: https://sumo.dlr.de/docs/Networks/PlainXML.html
[R11]: https://sumo.dlr.de/docs/Simulation/SaveAndLoad.html
[R12]: https://sumo.dlr.de/docs/Simulation/Randomness.html
[R13]: https://sumo.dlr.de/docs/Simulation/Output/TripInfo.html
[R14]: https://sumo.dlr.de/docs/Simulation/Output/Lanearea_Detectors_(E2).html
[R35]: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html
