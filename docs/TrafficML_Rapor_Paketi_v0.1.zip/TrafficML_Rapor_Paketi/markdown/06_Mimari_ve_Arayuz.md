# Sistem Mimarisi ve Arayüz Tasarımı

Bileşenler, veri sözleşmeleri, senaryo yaşam döngüsü ve 2D/3D tutarlılığı

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Mimari yaklaşım
**Öneri:** Modüler tek backend ve ayrı simülasyon worker'larıyla başlayalım. Uygulama adayları Python/FastAPI, PostgreSQL/PostGIS, dosya/nesne deposu ve web arayüzüdür. İş kuyruğu ürün yüküne göre seçilir; ilk günden çok sayıda mikroservis veya Kubernetes zorunluluğu yoktur.

SUMO kontrolü için Python TraCI arayüzü, toplu görsüz deneyler için libsumo seçeneği belgelenmiştir. [R10] Her worker ayrı çalışma dizini ve süreç kullanır. Simülasyon ile web istek işleyicisi aynı uzun işlem içinde bloke edilmez. Bu mimarinin hızı ve kaynak tüketimi henüz ölçülmemiştir.

## 2. Bileşen sorumlulukları
| Bileşen | Sorumluluk | Girdi / çıktı |
|---|---|---|
| PROJECT | Proje, yetki, bölge ve karar kayıtları | Proje kimliği, sürümler, onay durumu |
| DATA | Veri alma, köken, kalite ve eşleme | Ham gözlem → denetlenmiş veri sürümü |
| DESIGN | Şablonlar, kısıtlar ve ağ derleme | Parametreler → tasarım/ağ/metraj |
| MODEL / DIAG | Referans model ve olası nedenler | Gözlem + ağ → model kartı / kanıtlı hipotez |
| SIM | İş yönetimi ve motor adaptörü | Tasarım + talep + protokol → koşu çıktıları |
| ML / OPT | Ön tahmin, aday seçimi ve kapsam kontrolü | Deney veri seti → model / seçilmiş adaylar |
| COST | Fiyat kataloğu, metraj ve yaklaşık maliyet | Tasarım + fiyat sürümü → tahmin / eksik kalem |
| EVAL / REPORT | Ölçüt, yüzde, belirsizlik ve rapor | Uyumlu koşular → karşılaştırma ve belge |
| VIEW3D | Harita, yol modeli ve tekrar oynatımı | Aynı tasarım/koşu kimliklerinden görselleştirme |

**Sorumluluk sınırı:** Backend sayısal sonucu hesaplar; arayüz bağımsız başka formülle yüzde veya maliyet türetmez. 3D motor trafik fiziğinin sahibi değildir. Rapor üretici serbest metinden sayısal kazanım uydurmaz; kayıtlı metrikleri kullanır.

## 3. Bir deneyin yaşam döngüsü
Kullanıcı referans düzeni kilitler ve aday tasarımları oluşturur. Sistem şablon ve alan kısıtlarını doğrular, ağları derler, dış talepleri uygun bağlantılarla eşler. Deney manifesti oluşur; koşular iş kuyruğuna verilir. Worker log, metrik ve tekrar dosyalarını kaydeder. EVAL karşılaştırma anahtarını kontrol eder; rapor ve 3D aynı sonuç kaydından açılır.

Önerilen iş durumları: **draft → validating → queued → running → completed**. Alternatif son durumlar **invalid, failed, cancelled**. Kısmi tekrarların varlığı ayrıca kaydedilir; üç koşudan biri bitti diye deney bütünü tamamlanmış görünmez.

Kullanıcının hesaplamayı başlatması ile kayıtlı animasyonu oynatması iki ayrı eylemdir. “1x/2x” yalnız tekrar hızını değiştirir. Fiziksel parametre değişikliği yeni tasarım sürümü oluşturur; eski sonuçlar “önceki sürüm” etiketi alır ve yeniden hesaplama istenir.

## 4. Önerilen API sözleşmeleri
Bu uç noktalar tasarım taslağıdır; çalışan servis teslimi değildir.

| İşlem | Sözleşme özeti |
|---|---|
| POST /projects | Proje adı ve yetki bağlamından project_id oluşturur. |
| POST /projects/{id}/observations/import | Dosya, alan eşleme ve kaynak meta verisinden import_job_id döndürür. |
| POST /projects/{id}/designs | parent_design_id, template_id, parameters ve constraint_version alır. |
| POST /designs/{id}/validate | Kural bazında pass/fail/unknown ve gerekli ek girdileri döndürür. |
| POST /experiments | baseline_design_id, candidate_ids, demand_ids, protocol_id ve seed listesi alır. |
| GET /experiments/{id} | Tekrar bazında durum, ilerleme, hata ve çıktı kimliklerini döndürür. |
| POST /experiments/{id}/cancel | İdempotent iptal; süreç sonlandırılır, kısmi çıktılar korunur. |
| GET /runs/{id}/metrics | Ölçüt, birim, dönem, kapsam, kaynak türü ve kalite bayraklarını verir. |
| GET /runs/{id}/replay | Tekrar manifesti ve zaman parçalarının adreslerini verir. |
| POST /comparisons | Uyumlu sonuç kümesini karşılaştırır; uyumsuz koşulları reddeder. |
| POST /reports | Karşılaştırma kimliğinden sürümlü rapor oluşturur. |

İş başlatan isteklere idempotency anahtarı önerilir. Kullanıcıya ham SUMO komut satırı veya sistem yolu göndertmek yerine izinli alanlardan girdi üretilir. Dosya yüklemelerinde yol kaçışı, XML dış varlıkları, içerik boyutu ve kaynak kullanımı sınırlandırılır.

## 5. Sürüm ve tekrar üretim manifesti
Asgari manifest alanları: project_id, experiment_id, run_id, baseline_id, design_id, network_hash, demand_hash, control_plan_hash, routing_assumption, protocol_version, seed, software_version, environment, coordinate_transform, metric_version, cost_catalog_version ve artifact_hashes.

Karşılaştırma anahtarı; dış talep, dönem, değerlendirme sınırı, araç karışımı, davranış/rota varsayımı ve metrik tanımını kapsar. Ağ geometrisinin farklı olması fiziksel alternatifler için normaldir; bu nedenle yalnız aynı network_hash şartı aranmaz. Bunun yerine protokolün hangi tasarım değişikliklerine izin verdiği açık olmalıdır.

İlk sürümde tasarım değişiklikleri için temkinli geçersizleştirme önerilir. Sonraki optimizasyonda fiziksel, görsel ve maliyet bağımlılıkları ayrı hash'lerle izlenebilir. Yeniden kullanılan sonuç varsa aynı fiziksel modele dayandığı ve hangi kayıttan türetildiği raporda gösterilmeden kopyalanmaz.

## 6. 2D ve 3D üretim hattı
Tek tasarım tanımı hem SUMO ağını hem yol/şerit çizgilerini ve 3D ağı üretmelidir. Yol genişliği değişirken yalnız ekranın değişmesi veya ekran güncellenirken eski ağın çalışması kabul edilemez. SUMO FCD çıktısı araç konum/yön/zamanı için kullanılabilir. [R15] Harita üzerindeki 3D katman için MapLibre'nin three.js örneği teknik başlangıçtır. [R32]

Ağ yerel koordinatlarından harita ve sahne koordinatlarına tek dönüşüm tanımlanır. Testler, bilinen kontrol noktalarının ekranda aynı konuma gelmesini ve araçların doğru yönde ilerlemesini denetler. Kaydedilen zaman aralığı dışında konum üretilmez. Ara kare interpolasyonu yalnız görsellik içindir; metrik hesabı yapılmaz. Araç ağdan çıkınca kaybolur; başka bir yola doğrusal atlama animasyonu yapılmaz.

Önerilen ölçekleme yaklaşımı; yakındaki araçlar için ayrıntı, uzaktakiler için düşük ayrıntı, zaman parçalı tekrar yükleme ve tekrar dosyalarının sıkıştırılmasıdır. Bu önerilerin belirli FPS sağlayacağı henüz ölçülmemiştir. Simülasyon sonucu başarıyla hesaplanmış olsa da 3D performansının ayrı test edilmesi gerekir.

## 7. Kullanıcının görseline ilişkin ekran kararı
[IMAGE_UI]

**K03 — Kullanıcının paylaştığı konsept arayüz.** Bu görseldeki sayılar, maliyetler ve yüzdeler doğrulanmış trafik verisi değildir. Görsel ürün yönü ve yerleşim referansı olarak kullanılmıştır; gerçek saha görüntüsü veya çalışan prototip kanıtı değildir.

Sol düzenleme paneli, merkez mekânsal görünüm, sağ sonuçlar ve alt alternatif karşılaştırması korunabilir. Bunun önüne veri yeterliliği ve olası sorun kartları eklenmelidir. 2D ağ görünümü komşu bağlantıları ve etkiyi; 3D ise fiziksel düzeni anlatmalıdır.

## 8. Ekranlar ve gösterim kuralları
| Ekran | Ana içerik | Yanıltıcı sonucu engelleyen kural |
|---|---|---|
| Proje / Veri | Bölge, kaynaklar, eksikler, referans ağ ve veri dönemi | “Gözlemli / varsayımsal” durumu sayfa genelinde görünür. |
| Analizler | Hız/kuyruk zaman çizelgesi, kaynak hipotezleri ve kanıtlar | Hipotez ile kesin neden ayrılır; veri yetersiz sonucu desteklenir. |
| Simülasyon | Şablon, parametre, talep, kısıt ve iş durumu | Talep kaydırıcısı yeni senaryodur; gerçek canlı trafiği değiştirmez. |
| Öneriler | Kullanıcı/sistem adayları, gerekçe, maliyet ve yan etki | “ML ön tahmini” ile “simülasyon sonucu” ayrı etiketlidir. |
| Karşılaştırma | Aynı referansa göre mutlak değer, yüzde ve belirsizlik | Ortalama yanında en olumsuz etkilenen yaklaşım görünür. |
| Rapor | Girdi sürümleri, deneyler, sınırlılıklar ve karar notu | İncelenmemiş etki “0” değil “modellenmedi” olarak gösterilir. |

Görseldeki “kaza riski / yıllık kaza oranı” çıkarılır; kaynak kapsamın dışındadır. “Yaya güvenliği / yaşam kalitesi” için yöntem tanımlanmadığından skor üretilmez. FR-36'nın ölçülebilir ağaç, yeşil alan ve bisiklet uzunluğu göstergeleri kullanılır. CO₂ ayrı kapsam onayı olmadan eklenmez. [K01, s.1 ve FR-36]

“Anlık” sözcüğü, kayıtlı simülasyon saatini ifade ediyorsa başlık “Seçili simülasyon zamanı” olmalıdır. Araç sayısının azalması otomatik olumlu renk almamalı; daha az aracın ağa girebildiği bir başarısız koşu da aynı görünümü verebilir. Hangi ölçütün hangi yönde tercih edildiği açık yazılır.

## 9. Mimari karar kayıtları
| Karar | Öneri | Yeniden değerlendirme koşulu |
|---|---|---|
| ADR-01 Motor | SUMO adaptörü; netedit hazırlık/denetim | Pilot için gerekli hareket/geometriyi temsil edememe |
| ADR-02 Başlangıç mimarisi | Modüler backend + ayrı worker | Ölçülen kuyruk, kaynak veya ekip ihtiyacı |
| ADR-03 Görselleştirme | Ortak ağ sürümünden MapLibre/three.js | Hedef cihazda tekrar deneyinin başarısız olması |
| ADR-04 Öğrenme | Basit referans → ağaç modeli → gerekirse daha karmaşık model | Grup ayrımlı sonuçlarda belirgin eksik temsil |
| ADR-05 Otomasyon | Tanımlı şablonlar; saha kontrolü yok | Ayrı kapsam, veri ve kurum onayı |
| ADR-06 Rapor dili | Önce deterministik şablon; LLM zorunlu değil | Kaynaklı ve sayısal denetimli metin ihtiyacı oluşması |

**Açık kararlar:** Kimlik sağlayıcı, kuyruk ürünü, dağıtım ortamı, harita/3D varlık lisansları ve performans hedefleri. Bu belge hiçbir dış hesabın bağlandığı veya yazılımın kurulduğu anlamına gelmez.

## Kaynak bağlantıları

[R10]: https://sumo.dlr.de/docs/TraCI/Interfacing_TraCI_from_Python.html
[R15]: https://sumo.dlr.de/docs/Simulation/Output/FCDOutput.html
[R32]: https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-using-threejs/
