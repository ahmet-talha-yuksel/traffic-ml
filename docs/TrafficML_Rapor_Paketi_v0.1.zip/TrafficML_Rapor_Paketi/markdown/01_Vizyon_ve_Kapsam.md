# Ürün Vizyonu ve Proje Kapsamı

TrafficML | Kentsel Ulaşım Karar Destek Sistemi

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Amaç ve ürün tanımı
TrafficML çalışma adıyla ele alınan ürün; seçilen bir yol, kavşak veya küçük bölgenin trafik davranışını modelleyen, tıkanıklığın olası kaynaklarını açıklayan, tanımlı sınırlar içinde alternatif yol ve trafik düzenlemeleri oluşturan ve bu alternatiflerin etkilerini karşılaştıran bir karar destek sistemidir. Son kararı kullanıcı verir; prototip sahadaki sinyal cihazlarına komut göndermez.

**Temel karar sorusu:** Aynı değerlendirme döneminde mevcut düzen devam ederse ne olur; belirli bir yol veya sinyal düzenlemesi uygulanırsa ne değişir, neresi olumsuz etkilenir ve yaklaşık maliyet nedir?

Bu tanım, yüklenen 37 fonksiyonel gereksinim ile önceki TrafficML ön araştırma raporunun birlikte okunmasına dayanır. Fiziksel yol alternatifleri, maliyet ve 3D mevcut gereksinimlerdir. Olası neden analizi, gözleme dayalı doğrulama ve kanıtların sunulması ise önceki ürün vizyonunu gerçekleştirmek için bu pakette ayrıca önerilir. [K01, bölümler 3–8] [K02, bölümler 1–3]

## 2. Kaynaklar ve karar statüsü
| Kaynak / statü | Bu paketteki kullanımı |
|---|---|
| K01 — Kentsel_Ulasim_FR_Listesi.pdf, taslak v1.0, 01.10.2026 | 37 FR'nin kaynak metni; kimlikler ve özgün kapsam korunur. |
| K02 — TrafficML_Proje_Fikri_ve_On_Arastirma_Raporu.md, v0.1, 01.10.2026 | Sorun açıklama, referans gelecek ve pilot yaklaşımı için önceki vizyon. |
| K03 — Kullanıcının paylaştığı arayüz görseli | Etkileşim ve sunum referansı; üzerindeki sayılar gerçek sonuç değildir. |
| R01–R36 — Dış araştırma | Resmî belgeler ve özgün araştırmalar; açıklamalı kayıt 02 numaralı raporda. |
| ÖNERİ | Bu çalışmanın tasarım tercihi; ekip/danışman kabulü gerektirir. |
| AÇIK KARAR | Veri, saha ölçümü veya ekip kararı olmadan kesinleştirilemeyen konu. |

**Kaynaklar arasındaki fark görünür tutulmuştur:** K02, 3D'yi daha sonraki bir sunum seçeneği olarak anlatırken K01 FR-27–32 bunu açık gereksinim yapar. Bu paket, 3D'yi çıkarmak yerine pilot ölçekte gerçekleştirilecek gereksinim olarak ele alır. K02'deki gelecek talebi tahmini, K01 FR-20'deki tasarım performansı tahmininin yerine geçirilmez.

## 3. Hedef kullanıcılar ve iş akışı
İlk kullanıcı adayı, bir bölgedeki müdahaleleri teknik olarak değerlendiren ulaşım/plânlama uzmanıdır. Bu bir doğrulanmış müşteri profili değil, görüşmelerde sınanacak ürün varsayımıdır. İkinci rol, veriyi ve modeli hazırlayan analisttir. İnceleme rolü ise sonuçları, sınırları ve maliyetleri okuyabilir; model girdilerini değiştiremez.

Uzman, proje ve bölgeyi seçer; veri yeterliliğini görür; mevcut düzeni inceler. Kendi alternatifini oluşturabilir veya sistemin açıklamalı aday listesinden seçim yapabilir. Adaylar aynı talep senaryolarında değerlendirilir; kullanıcı ağ geneli, komşu yollar ve bütçe etkilerini birlikte inceler. Seçilen kararın gerekçesi ve reddedilen seçenekler rapora kaydedilir.

Ürünün iki giriş yolu vardır: **“Bir sorunu incele”** ve **“Bir tasarımı dene.”** Kullanıcı ikinci yolda teşhis aşamasını atlayabilir; ancak sonuç raporu hangi değişikliğin kullanıcı tarafından önerildiğini belirtir. Sistem üretimi ile kullanıcı üretimi alternatifler aynı doğrulama sürecinden geçer.

## 4. Mevcut kapsam ve sınırlar
| Alan | Kaynak kapsamı / bu paketin yorumu |
|---|---|
| Yol ve kavşak düzenlemeleri | Şerit ekleme/çıkarma, dönüş şeridi, kavşak ve sinyal değişiklikleri; parametreli şablonlar. [K01, FR-09] |
| Kentsel elemanlar | Refüj, ağaç, bisiklet yolu, kaldırım, yaya geçidi ve durak. [K01, FR-10–14] |
| Öğrenme | Simülasyon deneylerinden alternatif performansı tahmini. [K01, FR-19–20] |
| Maliyet ve karşılaştırma | Birim maliyet, metraj, bütçe filtresi, performans ve kentsel ölçütler. [K01, FR-22–26, FR-33–37] |
| 3D | Pilotun yol geometrisi, elemanları ve gerçek simülasyon tekrarları. [K01, FR-27–32] |
| Kapsam dışı | Kaza ve kaza-risk analizi; sınırsız otomatik geometri üretimi. [K01, s.1 ve s.3 kapsam notları] |
| Ayrı kapsam onayı gerekir | CO₂, yaşam kalitesi puanı, canlı saha kontrolü, şehir çapında sürekli güncelleme, uzun vadeli talep tepkileri. |

Kaza-risk analizi kapsam dışında olsa da izinli sinyal hareketleri ve minimum geçiş koşulları gibi **tasarım kısıtları** kaldırılmaz. Bunlar kaza olasılığı hesabı değildir. Yerel mühendislik koşulları uzman tarafından sağlanmadan sistem bir alternatife saha uygulama onayı vermez.

## 5. Pilot ve ilk uçtan uca teslim önerisi
**Öneri:** Ankara öncelikli aday kalsın; 3–5 bağlantılı kavşak ve gerekli yan yollar üzerinden veri erişimi araştırılsın. Bu sayı kesin saha sınırı değildir. Pilot, en yoğun yer olduğu için değil, ağının ve trafik girdilerinin doğrulanabilmesi nedeniyle seçilmelidir. FHWA planlama rehberi, analiz alanının etkileri ve kuyrukları kapsaması gerektiğini vurgular. [R01]

İlk uçtan uca teslim; mevcut düzen, bir sinyal düzenlemesi, bir fiziksel düzenleme ve bunların birleşimini değerlendirsin. Fiziksel aday olarak bir dönüş şeridi veya tanımlı şerit kullanım değişikliği önerilir; hangisinin seçileceği saha geometrisine bağlıdır. Döner kavşak dahil diğer FR-09 seçenekleri silinmez; geliştirme sırası 08 numaralı planda fazlandırılır.

Ağaç, yeşil alan ve bisiklet yolu ilk sürümde nicel envanter ve görselleştirme üretebilir. Hareketli yaya, bisiklet ve toplu taşıma etkileri raporlanacaksa talep ve davranış girdileri ayrıca bulunmalıdır. Bir elemanın ekranda bulunması, ilgili kullanıcı grubunun simüle edildiği anlamına gelmez. [R17–R20]

## 6. Veri olgunluğu ve kullanılabilecek iddialar
| Seviye | Ne gösterilebilir? | Ne iddia edilemez? |
|---|---|---|
| V0 — Sentetik deney | Yazılım akışı, bilinen sorun senaryoları, aday karşılaştırması | Gerçek Ankara trafiği veya sahada kazanım |
| V1 — Gözleme dayalı model | Belirli gözlemlere uyarlanmış ağ; ayrı veride doğrulama sonuçları | Her saat ve her bölgede aynı doğruluk |
| V2 — Güncellenen pilot | Zamanı ve kalite durumu görünen düzenli veriyle güncelleme | Kesintisiz ve denetimsiz saha kontrolü |

“Dijital ikiz” bu proje içinde V2'ye yönelen hedef olarak kullanılır. Sadece 3D harita veya sentetik simülasyon, gözlemlerle senkronize ve doğrulanmış bir ikiz olarak sunulmaz. Bu bir proje içi adlandırma kararıdır; evrensel bir standart tanımı iddiası değildir.

## 7. Başarı ve akademik katkı
Ürün başarısının ilk kanıtı, bir uzmanın aynı problem için birden fazla tasarımı oluşturup gerekçe, ağ etkisi, maliyet ve belirsizlikleri tek raporda izleyebilmesidir. Kullanıcı faydası, görüşme ve görev tamamlama deneyiyle sınanacaktır; bu araştırmada kullanıcı görüşmesi yapılmamıştır.

Akademik katkı için üç test edilebilir soru önerilir: Ağ ilişkilerini dikkate alan teşhis, yalnızca en yavaş kesimi seçen yaklaşımdan daha doğru kaynak gösterebilir mi? Simülasyon çıktılarından öğrenen model, aynı değerlendirme bütçesiyle daha yararlı adayların bulunmasına yardımcı olabilir mi? Açıklamalar ve yan etki göstergeleri, kullanıcının neden bir alternatifi seçtiğini denetlenebilir kılar mı? Bunlar hipotezdir; sonuçları henüz bilinmiyor.

**Açık kararlar:** Pilot sınırı, veri erişimi, ekip ve süre, ilk fiziksel müdahale, yaya/bisiklet talebi, kabul eşikleri ve müşteri görüşmeleri. Teknoloji seçimi de 02 ve 06 numaralı raporlardaki gerekçeli önerilerden sonra ekipçe dondurulacaktır.

## Kaynak bağlantıları

[R01]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter1.htm
[R17]: https://sumo.dlr.de/docs/Simulation/Pedestrians.html
[R20]: https://sumo.dlr.de/docs/Simulation/Shapes.html
[R36]: https://shap.readthedocs.io/en/latest/example_notebooks/overviews/Be%20careful%20when%20interpreting%20predictive%20models%20in%20search%20of%20causal%20insights.html
