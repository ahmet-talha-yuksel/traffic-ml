# Araştırma ve Tasarım Paketi

02 Ekim 2026 · v0.1

## Paketin amacı
TrafficML; seçilen bölgenin trafik davranışını modelleyen, sorunların olası kaynaklarını açıklayan ve tanımlı kısıtlar içinde birden fazla yol/sinyal düzenlemesini karşılaştıran karar destek ürünü olarak tasarlanmıştır. Mevcut düzenin devamı, müdahale alternatifleriyle aynı değerlendirme koşullarında karşılaştırılır.

**Teslim:** 8 ana rapor, 37 özgün fonksiyonel gereksinimin kabul/test bağlantıları, 12 önerilen ek fonksiyonel gereksinim, 8 önerilen kalite gereksinimi ve 36 dış kaynaklık açıklamalı tarama. Düzenlenebilir Word ve Markdown dosyaları, ayrı PDF’ler ve teknik ekler birlikte sunulur.

## Araştırmadan tasarıma geçen temel kararlar
**Fiziksel ve operasyonel düzenlemeler birlikte:** İlk bütünleşik prototip, mevcut düzenin yanında en az bir sinyal ve bir fiziksel şablonu çalıştırmalıdır. Sınırsız otomatik yol üretimi değil, parametreleri ve kısıtları belli seçenekler hedeflenir. K01 kapsamı korunur.

**Açıklama ve yan etki görünürlüğü:** Senaryo karşılaştırması ve 3D tek başına özgünlük iddiası değildir. Ürün katkısı; önerinin gerekçesini, eksik veriyi, komşu yollardaki etkileri ve karşılaştırma koşullarını birlikte görünür kılmakta araştırılacaktır. [R22] [R23]

**ML ön değerlendirmesi, simülasyonla kontrol:** FR-20, tasarım alternatiflerinin trafik performansını öğrenen bir model olarak korunmuştur. Önerilen yaklaşımda seçilen adaylar ayrıntılı simülasyonla yeniden sınanır; gelecekteki talep tahmini ayrı ve koşullu bir modüldür. [R25]

**Tek geometri ve sonuç kaydı:** 3D model, maliyet metrajı ve trafik simülasyonu aynı tasarım sürümüne dayanmalıdır. Geometri değiştiğinde eski sonuç geçersizleşir. Fiziksel alternatifler, sinyal değişikliklerinden farklı deney kurulumuyla karşılaştırılır. [R09] [R11]

## Bu paketin kanıt sınırı
Bu çalışma araştırma ve tasarım sürümüdür. Simülasyon çalıştırılmamış, ML modeli eğitilmemiş, saha verisi edinilmemiş veya trafik kazancı ölçülmemiştir. Ankara öncelikli pilot adayıdır; kesin bölge, veri erişimi, ekip, bütçe ve takvim açık kararlardır. Kaza ve kaza-risk analizi kapsam dışıdır. [K01]

## Belge haritası
Aşağıdaki aralıklar birleştirilmiş PDF’nin genel sayfa sırasıdır. Rapor altlıklarındaki sayfa numaraları her belge içinde yeniden başlar; PDF yer imleri doğrudan bölüm açar.

| Belge | İçerik / karar çıktısı | PDF sayfası |
|---|---|---|
| 01 — Vizyon ve Kapsam | Kullanıcı, ürün amacı, pilot ve kapsam sınırları | 3–5 |
| 02 — Araştırma ve Fizibilite | Benzer sistemler, yöntemler, veri erişimi ve 36 açıklamalı kaynak | 6–14 |
| 03 — Gereksinimler ve Kabul | 37 FR, 12 EK, 8 NF; kabul, bileşen ve test bağlantıları | 15–22 |
| 04 — Veri Stratejisi | Veri envanteri, ortak veri modeli, kalite ve veri talebi taslağı | 23–25 |
| 05 — Modelleme ve Yöntem | Şablonlar, olası kaynak analizi, ML ve aday seçimi | 26–28 |
| 06 — Mimari ve Arayüz | Bileşenler, API taslağı, iş durumu, 2D/3D ve ekran davranışı | 29–32 |
| 07 — Deney ve Doğrulama | Karşılaştırma protokolleri, metrikler ve test matrisi | 33–36 |
| 08 — Geliştirme Planı | İş paketleri, kilometre taşları, riskler ve açık kararlar | 37–40 |

## Kaynak ve karar etiketleri
**K01:** Kullanıcının 01.10.2026 tarihli 37 FR listesi. **K02:** TrafficML önceki ön araştırma raporu. **K03:** Gönderilen konsept arayüz; üzerindeki sayılar ölçülmüş sonuç değildir. **R01–R36:** Belge 02’de açıklanan dış kaynaklar. Tekil R bağlantıları tıklanabilir; inceleme düzeyi katalogda belirtilir.

Kaynakta olan gereksinim, araştırma bulgusu, projeye özgü öneri ve açık karar birbirinden ayrılmıştır. EK ve NF maddeleri onaylanmış kapsam değil, ekip değerlendirmesine sunulan eklerdir. Teknoloji seçimleri küçük teknik denemelerle kesinleştirilecektir.

## Dosyaların kullanımı
**Okuma:** Bu birleştirilmiş PDF veya ayrı rapor PDF’leri. **Düzenleme:** docx/ ve markdown/ klasörleri. **Geliştirme:** ekler/ içindeki kaynak kataloğu, gereksinim izlenebilirliği ve Mermaid şema kaynakları. README, dosya yapısını ve sürüm bilgisini açıklar.

## İlk karar oturumu
Önce Belge 01 ve 04 üzerinde pilotun sınırını, erişilebilir örnek veriyi ve ilk fiziksel düzenleme adayını kararlaştırın. Ekip kapasitesi ve teslim tarihiyle Belge 08’i güncelleyin. Ardından küçük referans ağ → iki alternatif → metrikler → 3D/karşılaştırma akışını çalıştıracak ilk teknik denemeye geçin.

## Kaynak bağlantıları

[R01]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter1.htm
[R09]: https://sumo.dlr.de/docs/Networks/PlainXML.html
[R11]: https://sumo.dlr.de/docs/Simulation/SaveAndLoad.html
[R22]: https://www.ptvgroup.com/en/products/ptv-vissim/faqs
[R23]: https://docs.aimsun.com/next/26.0.0/UsersManual/ScenariosExperimentsResultsReplications.html
[R25]: https://arxiv.org/html/2501.11057v1
[R36]: https://shap.readthedocs.io/en/latest/example_notebooks/overviews/Be%20careful%20when%20interpreting%20predictive%20models%20in%20search%20of%20causal%20insights.html
