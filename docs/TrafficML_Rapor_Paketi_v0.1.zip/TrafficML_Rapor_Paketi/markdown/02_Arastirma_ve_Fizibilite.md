# Ön Araştırma ve Teknik Fizibilite

Literatür, benzer sistemler, veri kaynakları ve karar gerekçeleri

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Araştırma yöntemi ve kanıt sınırı
Araştırma 02 Ekim 2026 tarihinde, mevcut 37 FR ve önceki vizyon raporundaki teknik sorular üzerinden yürütüldü. Resmî simülatör/API belgeleri, geliştirici ürün kılavuzları, kurum veri ve maliyet sayfaları ile özgün araştırmalar tarandı. Bu çalışma sistematik literatür taraması, patent araştırması veya kapsamlı pazar envanteri değildir.

İncelenen sorular: Fiziksel yol alternatifleri nasıl temsil edilebilir? Öneri gerekçesi ile nedensellik iddiası nasıl ayrılır? Alternatiflerin performansı öğrenilebilir mi? Ankara için hangi veri erişimi doğrulanabilir? 3D sahne ile hesaplanan ağ nasıl aynı tasarımda kalır? Maliyet ve deney güvenilirliği hangi kayıtları gerektirir?

**Yapılan çalışma:** Kaynak incelemesi, gereksinim eşleştirmesi ve tasarım sentezi. **Yapılmayan çalışma:** SUMO kurulumu/benchmark, ML eğitimi, saha sayımı, gerçek API anahtarıyla sorgu, birim fiyat pozlarının metraja uygulanması, müşteri görüşmesi ve gerçek trafik kazanımı ölçümü. Kayıtlarda kaynakta doğrulanan bilgi ile bizim önerimiz ayrılmıştır.

## 2. Benzer sistemler ve bizim geliştireceğimiz bölüm
| Sistem | Kaynakta belgelenen yetenek | Proje açısından değerlendirme |
|---|---|---|
| Eclipse SUMO + netedit | Mikroskobik/çok modlu simülasyon, ağ düzenleme ve programatik kontrol. [R05–R10] | Motoru yeniden yazmak yerine kaynak olarak kullanılabilir. Web iş akışı, teşhis, maliyet ve aday seçimi bizim geliştirmemizdir. |
| PTV Vissim | Senaryo yönetimi, performans ölçütleri, 2D/3D, otomasyon ve farklı kontrol arayüzleri. [R22] | Görselleştirme veya alternatif karşılaştırma tek başına yenilik değildir. Ekip için kullanılabilir lisans/modüller doğrulanmadı. |
| Aimsun Next | Senaryo, deney, sonuç, tekrar ve dinamik trafik atama yapısı. [R23] | Deney yönetimi olgun bir ürün kavramıdır. Bizim veri modelinde senaryo ile çalıştırma ayrı tutulmalı. |
| MATSim | Kişilerin günlük yolculuk planlarının ajan tabanlı etkileşimi. [R24] | Daha geniş talep ve davranış araştırması için referans. İlk şerit/kavşak pilotu için SUMO önerisini değiştirmiyor. |

Bu karşılaştırma ürünlerin bütün özelliklerini, doğruluklarını veya fiyatlarını puanlamaz. Üretici açıklamaları bağımsız performans kanıtı sayılmadı; belgede görülmeyen bir özellik “üründe yok” biçiminde kodlanmadı.

**Çıkarım:** Farklılaşma iddiası “3D trafik simülasyonu yapıyoruz” olmamalı. Araştırılacak ürün değeri; belirti–olası kaynak–uygun müdahale–deney sonucu bağlantısını, yerel veri sınırlılıklarını ve maliyet/yan etki hesabını erişilebilir bir iş akışında toplamak. Bunun gerçek bir pazar boşluğu olduğu henüz doğrulanmamıştır.

## 3. Literatürden çıkan teknik ayrımlar
### 3.1. Simülasyon performansını öğrenmek
Natterer ve çalışma arkadaşlarının 2025 tarihli genişletilmiş özeti, MATSim Paris örneğindeki müdahale senaryolarının çıktısını GNN ile yaklaşık öğrenir. İncelenen v1 çalışmada tüm yollar için test R² değeri 0,47 olarak raporlanır; dolaylı ağ etkileri, doğrudan müdahale etkilerinden daha zor öğrenilmektedir. Bu, FR-20 için dayanak oluşturur ama kusursuz bir “simülasyon yerine ML” sonucunu desteklemez. [R25]

**Tasarım önerimiz:** ML, adayları ön değerlendirsin; seçilen alternatiflerin nihai raporu doğrudan simülasyon tekrarlarından üretilsin. Modelin eğitim alanı dışındaki geometri/talep için ön tahmin durdurulsun veya açık uyarı verilsin. Sadece en iyi tahminleri seçmek yerine belirsiz adayları da deneyerek ön elemenin hatası ölçülsün.

### 3.2. Trafik tahmini farklı bir görevdir
Sroczyński ve Czyżewski'nin hakemli çalışması PeMS gözlemleri, Vissim ve LSTM/GRU/SAE deneylerini kullanır. Sınırlı veri ve deney düzeni, yeni fiziksel yol tiplerinin genel performansını çözdüğü anlamına gelmez. [R26] DCRNN ise yol ağının mekânsal ve zamansal bağımlılıklarını kullanan trafik tahmini yaklaşımıdır; burada yayın kaydı ve özet düzeyinde incelendi. [R27]

**Karar:** FR-20'nin ana görevi tasarımın performansını tahmin etmektir. Gelecek giriş talebini tahmin etmek ayrı ve opsiyonel modüldür. İki görev için veri seti, hedef değişken ve değerlendirme protokolü aynı tutulmayacaktır.

### 3.3. Komşu kavşak etkisi otomatik üstünlük sağlamaz
Dasgupta ve arkadaşlarının dijital ikiz/sinyal araştırması, komşu kavşağı hesaba katan ve katmayan iki yaklaşımı farklı talep düzeylerinde değerlendirir. Özet, komşu bilgisi içeren yaklaşımın her koşulda daha iyi olmadığını da bildirir. Tam deney düzeneği bu taramada yeniden üretilmedi. [R28]

**Çıkarım:** “Ağ bilgisi kullanıyoruz, dolayısıyla daha iyiyiz” demeyeceğiz. Yerel yaklaşım ile ağ etkili yaklaşımı aynı deney bütçesinde karşılaştıracağız. Kullanıcının istediği kaynak açıklaması, bu raporda sınanacak kural tabanlı hipotez modülü olarak tasarlanmıştır; doğrulanmış evrensel nedensellik algoritması değildir.

### 3.4. Açıklanabilirlik nedensellik değildir
SHAP'ın resmî açıklaması, tahmin modelindeki değişken katkılarının nedensel etki olarak yorumlanmasının sınırlılıklarını gösterir. [R36] Bu nedenle çıktı “olası açıklama + destekleyen gözlemler + alternatif açıklamalar + eksik veri” yapısında olacaktır. Gerçek olay kaydı olmadan kaza veya belirli dış olay tanısı konulmayacak; zaten kaza-risk analizi kaynak kapsamın dışındadır. [K01, s.1]

## 4. Veri fizibilitesi: ne doğrulandı?
| Kaynak | Doğrulanan | Hâlâ bilinmeyen / erişim sınırı |
|---|---|---|
| OpenStreetMap | Ağ içe aktarma yolu ve lisans/atıf çerçevesi belgeli. [R07, R31] | Seçilmeyen pilotun şeritleri, dönüşleri ve gerçek sinyalleri doğrulanmadı. |
| TomTom Flow Segment Data | Hız, seyahat süresi, serbest akış ve kalite alanları belgeli. [R29] | Ankara pilot kapsamı, ücret/kota ve saklama koşulları test edilmedi. Uç nokta toplam sayım veya sinyal fazı sağlamıyor. |
| Şeffaf Ankara | Resmî açık veri platformu tanıtımı doğrulandı. [R30] | Portalın dinamik içeriği tam okunamadı; kullanılabilir eşzamanlı sayım+sinyal veri paketi doğrulanamadı. |
| KGM 2026 | Yol işleri için 2026 birim fiyat listesi duyurusu doğrulandı. [R33] | Proje pozları, gerçek metraj, yerel ek maliyetler ve uygulama bedeli hesaplanmadı. |
| YFK aylık listeler | Resmî arama sonucunda aylık liste kaydı görüldü. [R34] | Doğrudan sayfa erişimi hata verdi; fiyat veya en güncel ay çıkarımı yapılmadı. |

ULASAV'ın Ankara veri kataloğu için arama ve açma denemesi yapıldı; trafik filtreli sayfa erişimi hata verdi. Bu sonuç “Ankara'da açık veri yok” diye yorumlanamaz. Veri erişimi hâlâ pilotun temel açık kararıdır. Sayım, dönüş, sinyal ve bağımsız performans gözlemleri için veri talebi taslağı 04 numaralı rapordadır.

## 5. Teknik seçim önerisi ve alternatifleri
**Simülasyon: SUMO.** Seçim gerekçemiz, mevcut FR'lerin gerektirdiği yol/şerit kontrolünü ve tekrarlanabilir deney geliştirmesini aynı açık araç setinde inceleyebilmek. Bu bir doğruluk veya hız benchmark sonucu değil, yetenek ve entegrasyon uygunluğu değerlendirmesidir. [R05–R10]

**Düzenleme: parametreli şablonlar ve ağ derleme.** netedit başlangıç modelinin denetimi için; web tasarım arayüzü ise sürümlü parametrelerin üretimi için kullanılacak. Döner kavşak gibi topoloji değişiklikleri, bağlantıların yeniden oluşturulmasını ve her alternatifte kontrol edilmesini gerektiren ayrı şablon ailesidir. [R06, R09]

**3D: MapLibre + three.js adayı.** Resmî MapLibre örneği, 3D modelin özel katmanda gösterilmesini sağlar. [R32] Bizim önerimiz, az sayıda doğrulanmış varlıkla başlayıp aynı ağ sürümünden yol modeli ve araç tekrarını üretmektir. Fotogerçekçilik veya belirli FPS henüz taahhüt edilmez.

**ML: önce basit referanslar, sonra ağaç tabanlı regresyon adayı.** Ortalama/k-en yakın örnek gibi referanslar ile ağaç tabanlı model karşılaştırılacak. GNN ilk zorunluluk değildir. Bu seçim veri hacmi ve grup ayrımlı test sonuçlarıyla gözden geçirilecek; model lisansı ve sürümü uygulama aşamasında kaydedilecektir.

## 6. Önceki tasarımın düzeltilmesi gereken noktaları
| Konu | Rapor paketine işlenen netleştirme |
|---|---|
| Tek snapshot ile bütün alternatifler | Sinyal değişikliği ve topoloji değişikliği ayrıldı. Aynı girdilerle yükleme tavsiyesi ve kaydedilmeyen durumlar dikkate alındı. [R11] |
| “Yoğunluk” etiketli araç/saat | Kaynak FR metni korundu; teknik sözlükte bunun akış/talep girişi olduğu açıklandı. Yoğunluk k ayrı değişkendir. |
| Kaza, güvenlik, yaşam kalitesi kartları | Kaza-risk kapsam dışı; diğer puanlar için kaynak FR'de ölçüm yöntemi yok. Uydurma puan üretilmeyecek. [K01, FR-36] |
| Refüj/ağaç ekleyince trafik yüzdesi | Görsel şekil ile simülasyon değişkeni ayrıldı. Dekoratif şekiller kendiliğinden trafik etkisi üretmez. [R20] |
| Geçen araç sayısı = kapasite | Geçiş sayımı korunur. Kapasite iddiası ayrı yöntem olmadan kullanılmaz. |
| Bir simülasyon sonucu = saha başarısı | Yazılım doğrulaması, saha modeli doğrulaması ve ML doğrulaması ayrı kabul kapıları oldu. |

## 7. Araştırma sonucu
Ürün yönünü destekleyen simülasyon, görselleştirme ve öğrenme bileşenleri belgelenmiştir. En büyük belirsizlik, “yapılabilir bir ekran” değil; pilot verisinin yeterliliği, müdahalelerin fiziksel uygulanabilirliği ve sonuçların ayrı gözlemlerle sınanmasıdır. İlk geliştirme yatırımı, görsel ayrıntıdan önce ağ–talep–ölçüm–alternatif zincirini doğrulamaya yönelmelidir.

Bu tarama, bütün kombinasyonlarda otomatik doğru teşhis veren bir yöntem veya veri olmadan sahada iyileşme garantisi bulmuş değildir. Buna karşılık, dar ve ölçülebilir bir pilot üzerinde bu hipotezleri sınayacak somut tasarım ve deney yolu ortaya koymaktadır.

## 8. Açıklamalı kaynak dökümü
Aşağıdaki 36 dış kaynak için inceleme seviyesi ayrıca yazılmıştır. Erişim tarihi 02.10.2026'dır. Ürün sayfaları yetenek beyanı; akademik makaleler kendi deney kapsamları içindeki bulgu; uygulama mimarisi ve eşikler ise bu paketin önerisidir.

### R01 — FHWA
**Traffic Analysis Toolbox III, Chapter 1: Microsimulation Analysis Planning** (2019).

Resmî teknik rehber; ilgili bölüm incelendi. Analiz sınırı, etkilenen bağlantılar ve çalışma amacının baştan tanımlanmasını destekler. Türkiye için bağlayıcı tasarım standardı olarak kullanılmamıştır.

Kaynağı aç: [R01]

### R02 — FHWA
**Traffic Analysis Toolbox III, Chapter 2: Data Collection and Analysis** (2019).

Resmî teknik rehber; ilgili bölüm incelendi. Geometri, kontrol, talep ve gözlenen performansın ayrı veri ihtiyaçları olduğunu gösterir. Pilot sayım ve veri kalite planına dayanak sağlar.

Kaynağı aç: [R02]

### R03 — FHWA
**Traffic Analysis Toolbox III, Chapter 5: Model Calibration** (2019).

Resmî teknik rehber; ilgili bölüm incelendi. Varsayılan simülatör parametrelerinin kalibrasyon sayılmadığını açıklar. Gözlenen zamana bağlı davranışın ve farklı koşulların temsil edilmesi önemlidir.

Kaynağı aç: [R03]

### R04 — FHWA
**Traffic Analysis Toolbox III, Chapter 6: Alternatives Analysis** (2019).

Resmî teknik rehber; ilgili bölüm incelendi. Alternatiflerin karşılaştırılabilir koşullarda, deney tekrarları ve değişkenlik dikkate alınarak incelenmesini destekler. Önerilen deney planı projeye özgü uyarlamadır.

Kaynağı aç: [R04]

### R05 — DLR / Eclipse SUMO
**SUMO Documentation: Introduction** (Güncellenen belge).

Resmî yazılım belgesi. Mikroskobik ve çok modlu trafik simülasyonu sunar; resmî giriş sayfası EPL 2.0 lisansını belirtir. Seçilecek dağıtım ve eklentilerin lisansları sürüm dondurulurken ayrıca kaydedilmelidir.

Kaynağı aç: [R05]

### R06 — DLR / Eclipse SUMO
**netedit** (Güncellenen belge).

Resmî yazılım belgesi. SUMO ağlarını oluşturup değiştiren görsel düzenleyicidir. Bizim web arayüzümüz veya otomatik tasarım öneri motorumuz değildir; hazırlık ve doğrulama aracı olarak değerlendirilmiştir.

Kaynağı aç: [R06]

### R07 — DLR / Eclipse SUMO
**OpenStreetMap Import** (Güncellenen belge).

Resmî yazılım belgesi. Açık haritanın ağ oluşturmak için kullanılabileceğini, bazı yol ve bağlantı bilgilerinin düzeltme gerektirebildiğini gösterir. Harita içe aktarımı saha doğrulamasının yerine geçmez.

Kaynağı aç: [R07]

### R08 — DLR / Eclipse SUMO
**Routes from Observation Points** (Güncellenen belge).

Resmî yazılım belgesi. Yol ve dönüş sayımlarına uyumlu rota/talep üretimi için routeSampler yaklaşımını açıklar. Eksik gözlemden gerçek başlangıç-varış dağılımının tekil biçimde bulunduğu varsayılmamalıdır.

Kaynağı aç: [R08]

### R09 — DLR / Eclipse SUMO
**PlainXML Network Definitions** (Güncellenen belge).

Resmî yazılım belgesi. Düğüm, yol, şerit ve bağlantı tanımları üzerinden programatik ağ üretimi için temel sağlar. Fiziksel alternatiflerin derlenebilir ağ sürümlerine çevrilmesinde kullanılır.

Kaynağı aç: [R09]

### R10 — DLR / Eclipse SUMO
**Interfacing TraCI from Python** (Güncellenen belge).

Resmî yazılım belgesi. Python üzerinden simülasyon yönetimini ve libsumo seçeneğini açıklar. Worker mimarisi bir proje önerisidir; gerçek çalışma süresi bu araştırmada ölçülmemiştir.

Kaynağı aç: [R10]

### R11 — DLR / Eclipse SUMO
**SaveAndLoad** (17 Temmuz 2025 sayfa tarihi).

Resmî yazılım belgesi. Durum kaydı, RNG ayarı ve ek girdi gereksinimleri açıklanır. Aynı girdilerle yükleme tavsiye edilir; bazı iç model durumları kaydedilmez. Topoloji değişikliklerinde evrensel snapshot eşitliği varsayılmaz.

Kaynağı aç: [R11]

### R12 — DLR / Eclipse SUMO
**Randomness** (Güncellenen belge).

Resmî yazılım belgesi. Rastgelelik kaynaklarını ve seed ayarını açıklar. Sürüm ve girdi manifestiyle birlikte tekrar üretilebilir deney kurgusunun teknik dayanağıdır.

Kaynağı aç: [R12]

### R13 — DLR / Eclipse SUMO
**TripInfo** (Güncellenen belge).

Resmî çıktı şeması. Seyahat, bekleme, zaman kaybı ve kalkış gecikmesi alanlarını tanımlar. Varsayılan çıktının varışta yazılması nedeniyle bitmeyen yolculukların ayrıca ele alınması gerekir.

Kaynağı aç: [R13]

### R14 — DLR / Eclipse SUMO
**Lanearea Detectors (E2)** (Güncellenen belge).

Resmî çıktı şeması. Şerit alanındaki durma, sıkışıklık ve kuyruk göstergeleri için dedektör tanımı sağlar. Eşikler ve algılama alanı uzunluğu raporlanmadan kuyruk ölçümleri karşılaştırılmamalıdır.

Kaynağı aç: [R14]

### R15 — DLR / Eclipse SUMO
**FCDOutput** (Güncellenen belge).

Resmî çıktı şeması. Araç kimliği, zaman, konum ve yön bilgileriyle simülasyon tekrarının görselleştirilmesine temel sağlar. Bu çıktı gerçek saha GPS ölçümü olarak etiketlenmez.

Kaynağı aç: [R15]

### R16 — DLR / Eclipse SUMO
**Traffic Lights** (Güncellenen belge).

Resmî yazılım belgesi. Sinyal programlarını ve kontrol seçeneklerini açıklar. Otomatik üretilen planın gerçek kavşak planına eşit olduğu varsayılamaz; saha/kurum verisiyle kontrol gerekir.

Kaynağı aç: [R16]

### R17 — DLR / Eclipse SUMO
**Pedestrians** (Güncellenen belge).

Resmî yazılım belgesi. Yaya ağı ve hareket modellerini açıklar. Yaya geçidinin sadece 3D çizilmesi ile yaya talebi ve etkileşiminin simüle edilmesi ayrı yeteneklerdir.

Kaynağı aç: [R17]

### R18 — DLR / Eclipse SUMO
**Bicycles** (Güncellenen belge).

Resmî yazılım belgesi. Bisiklet türleri, izinli şeritler ve davranış seçeneklerine temel sağlar. Bisiklet yolu uzunluğu ile bisikletli seyahat performansı birbirinden ayrılmalıdır.

Kaynağı aç: [R18]

### R19 — DLR / Eclipse SUMO
**Public Transport** (Güncellenen belge).

Resmî yazılım belgesi. Toplu taşıma hatları, duraklar ve duruş davranışları için bileşenleri açıklar. Sadece durak modeli eklemek yolcu hizmet düzeyini kendiliğinden hesaplamaz.

Kaynağı aç: [R19]

### R20 — DLR / Eclipse SUMO
**Shapes** (Güncellenen belge).

Resmî yazılım belgesi. Görsel şekillerin trafikle doğrudan etkileşmediğini belirtir. Dekoratif ağaç eklemesinden trafik iyileşmesi veya güvenlik puanı türetilmemesi kararına dayanak sağlar.

Kaynağı aç: [R20]

### R21 — DLR / Eclipse SUMO
**Emissions** (Güncellenen belge).

Resmî yazılım belgesi. Araç emisyon modelleri ve çıktı seçenekleri bulunur. Bu rapor emisyonu mevcut 37 FR içine eklemez; ayrı model, veri ve kapsam onayı gerektiren seçenek olarak kaydeder.

Kaynağı aç: [R21]

### R22 — PTV Group
**PTV Vissim: FAQs** (02 Ekim 2026 erişimi).

Üreticinin ürün/yetenek açıklaması; bağımsız kıyaslama değil. Senaryo yönetimi, 2D/3D, ölçütler ve otomasyon arayüzleri belgelenmiştir. Bu özellikler tek başına özgünlük iddiası değildir. Lisans ve modül kapsamı ekip için ayrıca doğrulanmalıdır.

Kaynağı aç: [R22]

### R23 — Aimsun
**Aimsun Next 26.0.0: Scenarios, Experiments, Results and Replications** (Sürüm 26.0.0 belgesi).

Üreticinin teknik kullanım kılavuzu. Senaryo, deney, tekrar ve dinamik rota atama ayrımını belgeler. Kendi alan modelimizde bu kavramların ayrılması için referanstır; ürünün her modülünü incelediğimiz anlamına gelmez.

Kaynağı aç: [R23]

### R24 — MATSim
**MATSim project overview** (Güncellenen proje sayfası).

Projenin resmî açıklaması. Kişilerin günlük plan ve yolculuklarının etkileşimini ajan tabanlı olarak ele alır. Daha geniş talep/davranış araştırması için adaydır; ilk pilotun şerit düzeyi motoru olarak önerilmemiştir.

Kaynağı aç: [R24]

### R25 — Natterer, E.; Engelhardt, R.; Hörl, S.; Bogenberger, K.
**Machine Learning Surrogates for Optimizing Transportation Policies with Agent-Based Models** (2025; arXiv:2501.11057v1; TRISTAN XII genişletilmiş özet).

Genişletilmiş özetin yöntem, sonuç ve sınırlılıkları incelendi. MATSim Paris örneğinde GNN ile senaryo çıktısının yaklaşık öğrenilmesini araştırır. Doğrudan etkilerde dolaylı etkilere göre daha güçlü sonuç bildirir; şehirler arası aktarım ve daha geniş müdahaleler açık çalışma alanıdır.

Kaynağı aç: [R25]

### R26 — Sroczyński, A.; Czyżewski, A.
**Road traffic can be predicted by machine learning equally effectively as by complex microscopic model** (2023; Scientific Reports 13, 14523; DOI:10.1038/s41598-023-41902-y).

Hakemli makale; veri ve deney bölümleri incelendi. PeMS gözlemleri, Vissim ve LSTM/GRU/SAE deneylerini kullanır. Sınırlı deney düzenindeki başarı, yeni kavşak geometrilerine veya Ankara koşullarına otomatik genellenemez.

Kaynağı aç: [R26]

### R27 — Li, Y.; Yu, R.; Shahabi, C.; Liu, Y.
**Diffusion Convolutional Recurrent Neural Network: Data-Driven Traffic Forecasting** (ICLR 2018; arXiv:1707.01926v3).

Yayın kaydı ve özet incelendi; yeniden üretim yapılmadı. Yönlü yol ağı ve zaman bağımlılıklarını birleştiren tahmin yaklaşımıdır. FR-20 tasarım performansı tahminiyle aynı görev değildir; opsiyonel talep tahmini araştırması için kaynaktır.

Kaynağı aç: [R27]

### R28 — Dasgupta, S.; Rahman, M.; Jones, S.
**Harnessing Digital Twin Technology for Adaptive Traffic Signal Control: Improving Signalized Intersection Performance and User Satisfaction** (2023; arXiv:2309.16673v1).

Araştırma kaydı ve özet incelendi; tam deney denetimi yapılmadı. Gelecek talebi ve paralel simülasyonu kullanan sinyal yaklaşımları anlatılır. Komşu kavşak bilgisini eklemenin her talep düzeyinde üstün sonuç vermediği bildirildiği için ağ etkisi katkısı ayrıca sınanmalıdır.

Kaynağı aç: [R28]

### R29 — TomTom
**Traffic API: Flow Segment Data** (Servis v4; sayfa 17 Nisan 2025).

Resmî API şeması incelendi; API anahtarıyla saha çağrısı yapılmadı. Hız, seyahat süresi, serbest akış değerleri, kalite göstergesi ve kapanma bilgisi sunar. Bu uç nokta toplam araç sayımı, dönüş akışı ve sinyal fazı sağlamaz; pilot kapsaması doğrulanmamıştır.

Kaynağı aç: [R29]

### R30 — Ankara Büyükşehir Belediyesi
**Şeffaf Ankara: resmî platform tanıtımı** (Tarih belirtilmemiş; 02 Ekim 2026 erişimi).

Resmî tanıtım incelendi; portalın dinamik içeriği tam okunamadı. Açık veri platformunun varlığı doğrulandı. Eşzamanlı kavşak sayımı ve sinyal fazlarını sağlayan kullanılabilir bir ham veri paketi bu taramada doğrulanmadı. Bu, verinin bulunmadığı anlamına gelmez.

Kaynağı aç: [R30]

### R31 — OpenStreetMap Foundation
**Copyright and License** (Güncel resmî sayfa).

Resmî lisans/atıf bilgisi incelendi. OSM verisinin ODbL çerçevesini ve atıf gereksinimini belirtir. Veri, harita döşemesi hizmeti ve kullanılan diğer varlıkların lisansları ayrı kaydedilmelidir; bu rapor hukuk görüşü değildir.

Kaynağı aç: [R31]

### R32 — MapLibre
**Add a 3D model using three.js** (Güncel resmî örnek).

Resmî örnek kod ve açıklama incelendi; performans deneyi yapılmadı. Özel katmanla three.js modellerinin haritaya eklenmesini gösterir. Web tabanlı 3D görünüm için uygulanabilir bir başlangıç noktasıdır, fakat binlerce hareketli araç için hız garantisi değildir.

Kaynağı aç: [R32]

### R33 — Karayolları Genel Müdürlüğü
**2026 Yılı Birim Fiyat Listesi duyurusu** (01 Ocak 2026 itibarıyla geçerli liste).

Resmî yayın duyurusu doğrulandı; poz bazlı maliyet hesabı yapılmadı. Yol, köprü, tünel, bitümlü kaplama, bakım ve trafik işleri için resmî maliyet kaynağı adayıdır. Yerel uygulama bedeli, metraj veya anahtar teslim teklif olarak kullanılmamıştır.

Kaynağı aç: [R33]

### R34 — Çevre, Şehircilik ve İklim Değişikliği Bakanlığı / YFK
**Aylık Güncel Rayiç ve Birim Fiyat Listeleri** (2026 listeleri).

Resmî arama sonucu doğrulandı; sayfa doğrudan açılırken hata alındı. Aylık tarih/sürüm takibi için kaynak adayıdır. Erişim sınırlı olduğundan hiçbir poz, fiyat veya en güncel ay bilgisi bu kaynaktan alınmış gibi sunulmamıştır.

Kaynağı aç: [R34]

### R35 — scikit-learn developers
**GroupKFold** (Güncellenen resmî belge).

Resmî yöntem belgesi. Çakışmayan gruplarla değerlendirme bölünmesini destekler. Projede tasarım kopyalarının ve farklı seed tekrarlarının eğitim-test arasında sızmasını önleme amacıyla önerilmiştir.

Kaynağı aç: [R35]

### R36 — SHAP developers
**Be careful when interpreting predictive models in search of causal insights** (Güncellenen resmî açıklama).

Resmî yöntem açıklaması. Tahmin açıklamasından nedensel etki sonucuna geçmenin sınırlılıklarını gösterir. Olası neden modülündeki çıktıların kanıtlı hipotez olarak adlandırılmasına dayanak sağlar.

Kaynağı aç: [R36]

## Kaynak bağlantıları

[R01]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter1.htm
[R02]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter2.htm
[R03]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter5.htm
[R04]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter6.htm
[R05]: https://sumo.dlr.de/docs/index.html
[R06]: https://sumo.dlr.de/docs/Netedit/index.html
[R07]: https://sumo.dlr.de/docs/Networks/Import/OpenStreetMap.html
[R08]: https://sumo.dlr.de/docs/Demand/Routes_from_Observation_Points.html
[R09]: https://sumo.dlr.de/docs/Networks/PlainXML.html
[R10]: https://sumo.dlr.de/docs/TraCI/Interfacing_TraCI_from_Python.html
[R11]: https://sumo.dlr.de/docs/Simulation/SaveAndLoad.html
[R12]: https://sumo.dlr.de/docs/Simulation/Randomness.html
[R13]: https://sumo.dlr.de/docs/Simulation/Output/TripInfo.html
[R14]: https://sumo.dlr.de/docs/Simulation/Output/Lanearea_Detectors_(E2).html
[R15]: https://sumo.dlr.de/docs/Simulation/Output/FCDOutput.html
[R16]: https://sumo.dlr.de/docs/Simulation/Traffic_Lights.html
[R17]: https://sumo.dlr.de/docs/Simulation/Pedestrians.html
[R18]: https://sumo.dlr.de/docs/Simulation/Bicycles.html
[R19]: https://sumo.dlr.de/docs/Simulation/Public_Transport.html
[R20]: https://sumo.dlr.de/docs/Simulation/Shapes.html
[R21]: https://sumo.dlr.de/docs/Models/Emissions.html
[R22]: https://www.ptvgroup.com/en/products/ptv-vissim/faqs
[R23]: https://docs.aimsun.com/next/26.0.0/UsersManual/ScenariosExperimentsResultsReplications.html
[R24]: https://matsim.org/
[R25]: https://arxiv.org/html/2501.11057v1
[R26]: https://www.nature.com/articles/s41598-023-41902-y
[R27]: https://arxiv.org/abs/1707.01926
[R28]: https://arxiv.org/abs/2309.16673
[R29]: https://docs.tomtom.com/traffic-api/documentation/tomtom-maps/v1/traffic-flow/flow-segment-data
[R30]: https://www.ankara.bel.tr/mobil-uygulamalar/seffaf-ankara
[R31]: https://www.openstreetmap.org/copyright
[R32]: https://maplibre.org/maplibre-gl-js/docs/examples/add-a-3d-model-using-threejs/
[R33]: https://www.kgm.gov.tr/Sayfalar/KGM/SiteTr/Duyurular/DuyuruDetay.aspx?Parameter=2014
[R34]: https://yfk.csb.gov.tr/aylik-guncel-rayic-ve-birim-fiyat-listeleri-113351
[R35]: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html
[R36]: https://shap.readthedocs.io/en/latest/example_notebooks/overviews/Be%20careful%20when%20interpreting%20predictive%20models%20in%20search%20of%20causal%20insights.html
