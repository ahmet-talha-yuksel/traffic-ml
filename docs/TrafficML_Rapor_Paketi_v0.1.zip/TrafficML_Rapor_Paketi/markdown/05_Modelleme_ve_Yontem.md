# Modelleme, Teşhis ve Alternatif Üretimi

Trafik modeli, fiziksel şablonlar, ML ve optimizasyon yöntemi

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Yöntemin bütünü
**Önerilen akış:** Ağ ve veri denetimi → mevcut düzen modeli → olası sorun analizi → kısıtlı alternatif üretimi → hızlı ön değerlendirme → simülasyon tekrarları → çok ölçütlü karşılaştırma. Kullanıcı doğrudan tasarım denemek isterse sorun analizi atlanabilir, fakat veri ve kısıt kontrolü atlanmaz.

Bu rapor yöntem tasarımıdır; anlatılan algoritmalar geliştirilmiş veya sahada doğrulanmış değildir. K01'in sınırsız geometri üretimini dışlayan kapsamı korunur. Mevcut FR-20 simülasyon performansı tahmini, ana ML görevi olarak alınır. [K01, FR-19–22 ve s.3 kapsam notu]

## 2. Mevcut düzen modelinin kurulması
Yol ağı haritadan başlatılır; şerit bağlantıları, dönüş izinleri, sinyal hareketleri ve duraklar denetlenir. SUMO PlainXML/netconvert hattı programatik ağ üretimi için, netedit görsel inceleme için adaydır. [R06, R07, R09] Gerçek talep için giriş ve dönüş sayımları kullanılır; routeSampler gözlemlere uyumlu rotalar üretmek için değerlendirilir. [R08]

**Önerilen model kartı:** Bölge sınırı; temsil edilen saatler; veri kaynakları; hangi parametrelerin gözlendiği/tahmin edildiği; araç karışımı; rota varsayımı; sinyal kontrol türü; yaya/bisiklet/toplu taşıma kapsamı; kalibrasyon/ayrı doğrulama sonuçları; geçerlilik sınırları.

Önce ağ kodlama hataları giderilir; sonra talep ve davranış uyumu değerlendirilir. Yanlış sinyal planını aşırı sürücü parametresi ayarıyla telafi etmeye çalışmak yerine kök girdi kontrol edilir. Varsayılan parametrelerin yerel kalibrasyon olmadığı FHWA rehberinde açıkça belirtilir. [R03]

## 3. Müdahale şablonu sözleşmesi
Her alternatif, yalnız bir ad veya 3D resim değil, çalıştırılabilir değişiklik paketidir. Önerilen şablon alanları: template_id, desteklenen ağ türü, değiştirilebilir parametreler, zorunlu girdiler, değişmezler, doğrulama kuralları, etkilenen fiziksel öğeler, metraj kuralları ve görsel öğeler.

| Şablon ailesi | Parametre / fiziksel değişiklik | Kontrol ve değerlendirme |
|---|---|---|
| Sinyal dağılımı / koordinasyon | Yeşil süreler, çevrim veya offset; izinli faz yapısı | Minimum geçişler ve hareket çakışmaları; yan kol bekleme etkisi |
| Dönüş cebi / şerit kullanımı | Depolama uzunluğu, izinli hareket, yaklaşım bağlantısı | Kullanılabilir kesit, kuyruk taşması, giriş/çıkış bağlantıları |
| Şerit ekleme/çıkarma | Şerit sayısı ve geometrisi; bağlantıların yeniden derlenmesi | Kesit sınırı, birleşme noktaları, komşu dar kesite taşan etkiler |
| Döner kavşak | Uzman tanımlı topoloji, giriş/çıkış ve öncelik parametreleri | Ayrı ağ ve rota kontrolü; gap-acceptance/yerel davranış incelemesi |
| Refüj / yeşil alan | Kesit kullanımı ve varsa dönüş kısıtı; metraj | Dekor ile fiziksel alan kaybı ayrılır; otomatik trafik faydası yok |
| Bisiklet / yaya | İzinli bağlantılar, yol/geçit geometrisi ve varsa talep | Süreklilik, karşılıklı etkileşim ve modellenmeyen etkiler |
| Durak | Konum, cep/şerit ilişkisi ve duruş davranışı | Hat/araç girdileri, duruş süresi ve kuyruk etkisi |

Bu tablo gerçek mühendislik boyutları önermez. Sayısal genişlikler, süreler ve uygunluk sınırları pilot girdileri ve uzman incelemesiyle belirlenir. “Sinyal çakışması yok” gerekli bir model kontrolüdür; tek başına tüm saha güvenliğinin kanıtı değildir.

## 4. Uygulanabilirlik kontrolü
Önerilen kısıtlar dört gruptadır: fiziksel alan, ağ bağlantısı, trafik işletimi ve bütçe. Kullanılabilir kesit aşılmamalı; yaya/bisiklet bağlantıları silinmemeli; araçların zorunlu giriş/çıkışları kopmamalı; korunacak alanlar çakışmamalı. Bilinmeyen genişlik veya fiyat, otomatik uygunluk üretmez.

Bir aday üç durumdan birini alır: **model kısıtlarını geçti**, **uzman/veri incelemesi bekliyor**, **kısıt ihlali nedeniyle elendi**. İlk durum “inşa edilebilir ve onaylı” anlamına gelmez. Kısıt raporu, hangi kuralın hangi girdiyle kontrol edildiğini saklar.

Ağaçlandırma görsel olarak uygulanabilirken trafik modelini hiç değiştirmeyebilir. SUMO şekilleri kendi başına trafiği etkilemez. [R20] Dolayısıyla yalnız dekor değişen deneyde gecikme kazanımı üretilmesi bir hata testidir; arazi/kesit gerçekten değişmişse etki bu fiziksel değişiklik üzerinden hesaplanır.

## 5. Olası neden analizi — araştırma tasarımı
### 5.1. Hipotezler
| Kod | Olası açıklama | Destek için aranacak gözlem | Ayırt edilmesi gereken durum |
|---|---|---|---|
| H-01 | Aşağı-akım kuyruğu çıkışı engelliyor | Çıkış depolamasının dolması; önce aşağı akım, sonra yukarı akım yavaşlama | Ortak talep artışı veya ölçüm zaman kayması |
| H-02 | Dönüş kuyruğu diğer hareketi engelliyor | Dönüş kuyruğu depolamayı aşıyor; ilgili hareket blokajı | Genel çıkış yetersizliği |
| H-03 | Yeşil dağılımı/koordinasyon talebe uymuyor | Hareket bazında talep, kullanılan yeşil ve boşalma davranışı | Aşağı-akım doluluğu yüzünden kullanılamayan yeşil |
| H-04 | Talep artışı mevcut hizmeti aşıyor | Dış girişlerde artış; birikim ve zaman sırası | Sinyal değişikliği, durak/şerit kaynaklı kayıp |

Bu hipotezler bu projede önerilmiştir; literatürden doğrulanmış başarı oranı aktarılmaz. Sistem görünür en uzun kuyruğu otomatik kaynak ilan etmez. Ağ grafiği üzerinde komşu hareketler ve zaman sırası birlikte incelenir. Hız verisi tek başına iki hipotezi ayırt etmiyorsa çıktı kararsız kalabilir.

### 5.2. Çıktı sözleşmesi
Teşhis kaydı; hedef bölge, dönem, aday kaynak, hipotez kodu, destekleyen gözlem kimlikleri, karşı bulgular, veri yeterliliği ve alternatif açıklamaları içerir. “Güven yüksek” gibi ifadeler kullanılacaksa bunun bir olasılık mı yoksa kurallı kanıt düzeyi mi olduğu açık olmalıdır. Kalibre edilmemiş skor yüzde olasılık olarak gösterilmez.

Hipotez değerlendirme aşamasında kapasite veya kontrol üzerinde sanal değişiklik denenebilir. Bu, mekanizmanın model içinde mümkün olduğunu gösterir; gerçek hayattaki nedenin kanıtı değildir. Öğrenilmiş değişken önemini gerçek nedensellik olarak yorumlama sınırı ayrıca korunur. [R36]

## 6. Tasarım performansı için ML
### 6.1. Girdi ve hedef
Önerilen girdiler: tasarım ailesi, şerit/bağlantı özellikleri, dönüş cebi, sinyal parametreleri, talep profili, araç karışımı ve referans model tanımları. Hedefler: bekleme, seyahat süresi, kuyruk, geçen araç sayısı ve varsa ağ/yan kol ölçütleridir. Gerçek adayın sonradan oluşan gecikmesini girdi yapmak hedef sızıntısıdır.

Ağaç sayısı gibi yalnız görsel değişkenler, fiziksel bir etkisi tanımlı değilse trafik performansı modeline nedensel etken gibi verilmez. Maliyet ve yeşil alan hesapları bilinen metrajdan deterministik olarak üretilir; gereksiz yere ML'ye bırakılmaz.

### 6.2. Veri üretimi ve ilk model
Önce geçerli parametre uzayı tanımlanır; örnekler hem normal hem sınır durumları kapsar. İlk küçük çalışma için **20 tasarım konfigürasyonu × 3 talep profili × 5 seed = 300 koşu** yalnız bir iş yükü varsayımıdır. Bu sayı yeterli eğitim seti veya nihai tekrar sayısı iddiası değildir. Koşu süresi ölçüldükten sonra bütçe ve örnekleme planı gözden geçirilir.

Her konfigürasyonun tekrarları aynı grupta tutulur. Rastgele satır bölmesi yerine tasarım-gruplu eğitim/doğrulama/test ayrımı önerilir; farklı bir talep rejimi ve görülmeyen şablon ailesi için ayrıca kapsam dışı test yapılır. Grup bazlı ayırma için GroupKFold benzeri resmî araçlar kullanılabilir. [R35]

İlk karşılaştırma, basit ortalama/benzer örnek referansı ile ağaç tabanlı regresyon adayıdır. Veri ve hata analizi gerekçe oluşturursa daha karmaşık ağ modellerine geçilir. Hatalar sadece R² ile değil, birimli MAE/RMSE, aday sıralama hatası, düşük tahmin edilen yan etkiler ve seçimin doğurduğu performans kaybıyla ölçülür.

### 6.3. Ön değerlendirme ve yeniden doğrulama
ML, hızlı ön tahmin etiketiyle aday sıralamasına yardımcı olur. Yüksek fayda tahminli adaylar, belirsiz adaylar ve birkaç kontrol örneği simülasyona alınır. Seçilen alternatifler ayrılmış doğrulama seed'leriyle yeniden çalıştırılır. Rapor gerçek koşu sonuçlarını esas alır; hızlı tahminin ne kadar yanıldığı da saklanır.

Modelin kalibrasyonu bozuk bir simülatörü doğru taklit etmesi mümkündür. Bu nedenle simülatörün saha geçerliliği ve ML'nin simülatörü taklit etme başarısı iki ayrı testtir. Bu ayrım kaynak FR-20'yi değiştirmez; kabul ölçütünü netleştirir.

## 7. Çok ölçütlü karşılaştırma ve durma koşulu
İlk aşamada aday sayısı sınırlı tutularak açık bir tarama önerilir. Önce kısıt ihlalleri ve bütçe durumu değerlendirilir. Sonra gecikme/seyahat, kuyruk/yan yol etkisi, maliyet ve nicel kentsel göstergeler ayrı sunulur. Bir ölçütte iyi olup diğerinde kötü olan adaylar gizlenmez.

Tercih ağırlıkları kullanılacaksa bunlar kullanıcı girdisidir; normalizasyon, ağırlık ve kısıtlar rapora yazılır. Tek puanın yanında ham ölçütler korunur. Bir aday diğerlerinden her önemli ölçütte kötü değilse seçenek kümesinde kalabilir; nihai tercih insan incelemesidir.

Çıktı “küresel olarak en iyi yol” değil, **incelenen adaylar ve varsayımlar içindeki karşılaştırma** olacaktır. Geçerli aday yoksa veya yan etki sınırları aşılıyorsa sistem bunu sonuç olarak sunar. Optimizasyon başarısı ile her durumda faydalı müdahale bulma zorunluluğu karıştırılmaz.

## 8. Gelecek talebi ve uzun vadeli etkiler
Yakın gelecek giriş talebi tahmini veri yeterliyse eklenebilir; son değer ve benzer gün/saat referanslarıyla zaman sıralı test yapılır. Bu modül, müdahale sonrası hızları simülasyona zorla dayatmaz. Tahmin edilen dış talep, referans ve müdahale senaryolarının ortak girdisidir.

Yol düzeninin uzun vadede güzergâh, ulaşım türü veya toplam talebi değiştirmesi ayrı modelleme konusudur. İlk ürün kısa vadeli/koşullu senaryo etkisini gösterir. “Bu kavşak her yıl şu kadar trafik azaltır” gibi genellemeler, yıllık talep ve kullanım koşulları modellenmeden yapılmaz.

## Kaynak bağlantıları

[R03]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter5.htm
[R06]: https://sumo.dlr.de/docs/Netedit/index.html
[R07]: https://sumo.dlr.de/docs/Networks/Import/OpenStreetMap.html
[R08]: https://sumo.dlr.de/docs/Demand/Routes_from_Observation_Points.html
[R09]: https://sumo.dlr.de/docs/Networks/PlainXML.html
[R20]: https://sumo.dlr.de/docs/Simulation/Shapes.html
[R35]: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html
[R36]: https://shap.readthedocs.io/en/latest/example_notebooks/overviews/Be%20careful%20when%20interpreting%20predictive%20models%20in%20search%20of%20causal%20insights.html
