# Veri Stratejisi ve Veri Modeli

Pilot erişimi, veri sözlüğü, kalite, saha planı ve maliyet verisi

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Veri stratejisi
Kaynak FR-05–08 manuel talep girişini destekler. Buna ek olarak gerçek bölgeyi açıklamak için gözlem verisi gerekir. **Önerilen yaklaşım:** Sentetik deney hattı ile gerçek pilot veri hattı aynı şemayı kullansın; fakat hiçbir sonuçta kaynak türü gizlenmesin. [K01, bölüm 2]

Bu çalışmada gerçek pilot verisi edinilmemiştir. Ankara adaydır; veri erişim durumu “araştırıldı, doğrulanmadı”dır. Platform tanıtımı veya bir haritada trafik renklerinin görülmesi; yeniden kullanılabilir, zaman damgalı ham akış ve sinyal veri erişimini kanıtlamaz. [R29, R30]

## 2. Asgari veri envanteri
| Veri | Asgari alanlar ve kullanım | Erişim planı / eksikse davranış |
|---|---|---|
| Ağ geometrisi | Kavşak, yol, şerit, bağlantı, yön, genişlik, hız, koordinat sistemi | OSM başlangıcı + yerinde/kurumsal kontrol. Eksik özellik varsayım etiketli. [R07] |
| Sinyal | Hareket-faz eşleşmesi, süre, offset, kontrol türü ve geçerlilik zamanı | Kurumsal plan veya eşzamanlı gözlem. Eksikse saha önerisi iddiası yok. |
| Giriş/dönüş sayımı | Zaman aralığı, yön/hareket, araç sayısı, sınıf ve sensör konumu | Manuel/izinli sayım veya kurum verisi. Hızdan tek başına sayı türetilmez. |
| Performans gözlemi | Koridor seyahat süresi, hız, kuyruk ve zaman | Model kurma verisinden ayrı doğrulama dilimleri saklanır. |
| Yaya/bisiklet | Girişler, hedef bağlantılar, sayım aralığı, geçit kullanımı | Dinamik etki gösterilecekse gerekir; yoksa envanterle sınırlanır. |
| Otobüs/durak | Hat/rota, sefer profili, duruş süresi ve durak geometrisi | Gerçek sefer yoksa varsayımsal profil etiketi; hizmet puanı üretilmez. |
| Müdahale alanı | Kullanılabilir kesit, korunacak alan, izinli değişiklik ve bilinmeyenler | Kurum/uzman girdisi; ölçülmeyen genişlik uygulanabilirlik onayı olmaz. |
| Maliyet | Poz, birim, fiyat tarihi, para birimi, dahil/haric kalemler | KGM/YFK veya kurumsal liste; gerçek poz eşleme ve metraj henüz yapılmadı. [R33, R34] |

Veri toplama planı, bir tek “trafik yoğunluğu” dosyasına indirgenmez. Geometri, kontrol, talep ve performans gözlemlerinin birlikte planlanması gerekir. [R02]

## 3. Kavram ve birim sözlüğü
| Alan | Tanım / birim | Kritik ayrım |
|---|---|---|
| flow_count | Belirli aralıkta geçen araç sayısı; araç | Sayım süresi olmadan araç/saat olmaz. |
| flow_rate | Sayımın zamana oranı; araç/saat | Kaynak FR'deki araç/saat yoğunluk girdisinin teknik karşılığı. |
| density | Yol uzunluğu başına araç; araç/km/şerit veya belirtilen kapsam | Akış ve hızdan koşulsuz hesaplanmayacak; ayrı ölçüm/kestirim. |
| speed | Açıkça belirtilmiş ortalama türü; m/s veya km/saat | Gözlenen segment ortalaması ile araç anlık hızı farklıdır. |
| queue_length | Eşik ve ölçüm alanına göre kuyruk; m/araç | Dedektör sınırına ulaşma “daha uzun olabilir” bayrağı üretir. |
| travel_time | Tanımlı iki sınır arasında süre; saniye | Ağda kalan araçların tamamlanmış seyahat süresi yoktur. |
| value_kind | observed / assumed / estimated / simulated | ML ön tahmini estimated; simülasyon simulated. |
| quality_flag | missing / suspect / valid / imputed | Eksik değer ile sıfır ayrı tutulur. |

**Zaman:** Ham zaman dilimi korunur; depolamada UTC ve gösterimde Europe/Istanbul kullanılması önerilir. Sayım aralığı başlangıç/bitişi, sinyal olay zamanları ve simülasyonun sıfır zamanı birlikte tanımlanır. Sinyal değişimleri, beş dakikalık ortalamaya indirgenerek faz bilgisi kaybedilmez.

**Mekân:** Harita koordinatları, yerel metrik ağ koordinatları ve 3D sahne orijini ayrı saklanır. Uzunluk/alan hesapları enlem-boylam derecelerinde yapılmaz; projeksiyon ve dönüştürme sürümü manifestte tutulur.

## 4. Önerilen alan modeli
| Varlık | Temel alanlar | Bağlantı |
|---|---|---|
| Project / StudyArea | id, owner, boundary, intervention_boundary | Birden çok ağ ve deney içerir. |
| NetworkVersion | id, source_hash, geometry_hash, CRS, validation_status | Tasarım ve çalışma ağı sürümleri. |
| Observation | source_id, start/end, element_id, metric, value, unit, kind, quality | Değiştirilmeyen ham kayıt + ayrı temizleme sürümü. |
| DemandVersion | trips/counts, vehicle_mix, routing_assumption, profile_hash | Ağdan bağımsız dış talep; ağla eşleme kaydı ayrıca. |
| ControlPlan | movement_map, phases, durations, offsets, validity | İlgili ağ bağlantılarıyla tutarlı. |
| DesignVersion | parent_id, template, parameters, constraints, geometry_hash | Kentsel elemanlar ve metrajla aynı kimlik. |
| Experiment / Run | design, demand, protocol, seed, software, status | Bir deney farklı koşular içerir. |
| Metric / Trajectory | run_id, interval, scope, units, quality | Sonuç ve 3D tekrar ortak run_id kullanır. |
| CostCatalog / Estimate | source_date, items, quantity, units, unknown_items | Fiyat güncellenince eski deney maliyeti sessizce değişmez. |
| Diagnosis / Report | evidence_ids, hypotheses, limits, compared_run_ids | Her açıklama ve sonuç kanıta geri gider. |

Büyük araç tekrarlarının ilişkisel tablolarda kare kare tutulması zorunlu değildir. PostgreSQL/PostGIS meta veriyi; dosya/nesne deposu ise sıkıştırılmış çıktı ve tekrar dosyalarını tutabilir. Bu bir mimari öneridir; kapasite hesabı ölçümden sonra yapılacaktır.

## 5. Kalite ve köken kontrolleri
İçe aktarma, ham kayıtları değiştirmeden saklar. Temizlenmiş kayıt yeni bir sürüm üretir. Birim kontrolü, koordinat geçerliliği, zaman çakışması/boşluğu, negatif sayım, oran toplamı ve mükerrer kayıt kontrol edilir. Sensörün hangi şerit/harekete baktığı bilinmiyorsa bütün kavşağı temsil ettiği varsayılmaz.

Giriş ve çıkış sayıları arasındaki fark, içerideki birikimle birlikte incelenir; ölçüm penceresi ve araçların henüz çıkmamış olması gözetilir. Sayım uyuşmazlığı otomatik olarak sensör hatası veya olay tanısı değildir. İmputasyon yapılırsa yöntem ve doldurulan pay ayrıca görünür.

TomTom kalite alanı, servisin hız/seyahat süresi verisinin kalitesini belirtir; bizim neden analizimizin olasılığı değildir. API'nin yakın yol seçimi ve konum eşleme hatası kontrol edilmelidir. Aynı fiziksel yol için OSM ve sağlayıcı kimlikleri doğrudan eşit sayılmaz. [R29]

## 6. Pilot gözlem ve doğrulama planı — öneri
Önce aday alan gezilerek ağ sınırı, sayım noktaları ve alternatif güzergâhlar belirlenir. Ardından bir deneme gözlem oturumu yapılır; veri çözünürlüğü, gözlemci kapasitesi ve sinyal eşleme hataları anlaşılır. Tek bir oturum kalibrasyon yeterliliği olarak kabul edilmez.

Başlangıç çalışma varsayımı, farklı günlerde aynı yoğun saat çevresinin ve bir daha sakin koşulun gözlenmesidir. Gerekli gün/oturum sayısı pilot değişkenliği, izinler ve ölçüm kaynaklarıyla belirlenir. Kalibrasyon için kullanılan dönemler ile bağımsız değerlendirme dönemleri önceden ayrılır; nihai test verisi sürekli model ayarlamasına açılmaz.

Ham video gerekli değilse kimliksiz sayımlar tercih edilir. Görüntü kullanımı seçilirse erişim, saklama süresi ve paylaşım yetkisi kurumla belirlenmeden toplama yapılmaz. Bu rapor izin alınmış veya hukuki uygunluk kesinleşmiş kabul etmez.

## 7. Maliyet verisi ve hesap sınırı
**Önerilen hesap:** C = toplam(miktar_i × birim_fiyat_i) + açıkça tanımlı ek kalemler. Asfalt için hangi tabakaların, kazı/taşımanın, işaretlemenin ve geçici trafik yönetiminin dahil olduğu ayrı yazılır. Mevcut yüzeyin yalnızca yeniden işaretlenmesiyle yeni yol inşası aynı maliyet şablonu değildir.

Yol genişliği, uzunluk ve katman kalınlığı farklı metraj birimlerine dönüşür. m², m³, ton ve adet karıştırılmaz. Taşıma, altyapı deplasesi, kamulaştırma, vergi, bakım ve peyzajın varlığı/yokluğu ayrıca kaydedilir. Kullanılmayan kalem “0”; bilinmeyen kalem “bilinmiyor” durumundadır.

Bütçe kontrolünde üç durum kullanılmalıdır: **bilinen kapsamda uygun, bilinen kapsamda aşıyor, eksik bilgi nedeniyle değerlendirilemiyor.** Fiyat belirsizliği aralığı kullanılan tahmin yöntemine bağlıdır; keyfî ± yüzde, istatistiksel güven aralığı olarak sunulmaz.

## 8. Kuruma veri talebi taslağı — gönderilmedi
Üniversite mezuniyet projesi kapsamında, seçilecek sınırlı bir koridorda mevcut düzen ve alternatif yol/sinyal düzenlemelerinin simülasyonla karşılaştırılması amaçlanmaktadır. Uygun görülecek tarih aralıkları için kimliksiz araç ve dönüş sayımları; sensörlerin konum ve yönleri; sinyal faz/süre planları ve değişim kayıtları; yol/şerit bağlantıları; varsa kuyruk ve seyahat süresi ölçümleri hakkında veri paylaşım imkânını değerlendirmek istiyoruz.

Veriler yalnız araştırma modelinin kurulması ve bağımsız doğrulaması için kullanılacak; saklama, yayın ve üçüncü taraf paylaşım koşulları kurumla ayrıca kararlaştırılacaktır. Canlı trafik kontrolü veya kişisel hareket takibi hedeflenmemektedir. Kesin pilot sınırı, tarih aralığı, sorumlu ekip ve danışman bilgileri belirlenince talep bu alanlarla tamamlanacaktır.

**Gönderim öncesi eksikler:** Kurum muhatabı, ekip/danışman onayı, pilot sınırı, istenen dönem, izin ve saklama koşulları. Bu taslak bir veri paylaşım anlaşması değildir.

## Kaynak bağlantıları

[R02]: https://ops.fhwa.dot.gov/publications/fhwahop18036/chapter2.htm
[R07]: https://sumo.dlr.de/docs/Networks/Import/OpenStreetMap.html
[R29]: https://docs.tomtom.com/traffic-api/documentation/tomtom-maps/v1/traffic-flow/flow-segment-data
[R30]: https://www.ankara.bel.tr/mobil-uygulamalar/seffaf-ankara
[R33]: https://www.kgm.gov.tr/Sayfalar/KGM/SiteTr/Duyurular/DuyuruDetay.aspx?Parameter=2014
[R34]: https://yfk.csb.gov.tr/aylik-guncel-rayic-ve-birim-fiyat-listeleri-113351
