# Geliştirme Planı, Riskler ve Teslimler

İş paketleri, bağımlılıklar, aşama kapıları ve açık kararlar

**Sürüm:** 0.1 · 02.10.2026 · Ekip değerlendirmesine açık taslak

## 1. Planlama varsayımları
Bu plan, ekip büyüklüğü, teslim tarihi ve veri erişimi kesinleşmeden hazırlanmış bağımlılık temelli bir geliştirme önerisidir. İsim, kesin takvim veya satın alma bütçesi uydurulmamıştır. Roller gerçek kişilere ekip toplantısında atanacaktır. Kod, veri toplama ve deney yürütme henüz yapılmış sayılmaz.

Amaç bütün şehri aynı anda modellemek değil; küçük bir pilotta veri → analiz → fiziksel/işletim alternatifi → simülasyon → maliyet ve yan etki → 3D/rapor zincirini tamamlamaktır. 37 FR hedef kümesi korunur; bir kilometre taşında ertelenen özellik kapsamdan sessizce çıkarılmaz.

## 2. Önerilen kilometre taşları
| Aşama | Gösterilecek çalışan çıktı | Bilinçli sınır |
|---|---|---|
| M1 — En küçük bütünleşik prototip | Proje ve pilot ağ; elle talep; referans, bir sinyal ve bir fiziksel şablon; temel metrikler; gerçek koşu verisiyle sade 3D ve karşılaştırma | Bütün şehir, fotogerçekçilik, geniş şablon kataloğu ve canlı kurum entegrasyonu yok |
| M2 — Tasarım ve veri derinliği | FR-09–14 için genişleyen şablonlar; maliyet/metraj/bütçe; veri kaynağı ve mevcut durum doğrulama akışı | Gerçek veri yoksa saha geçerliliği kapısı geçilmiş sayılmaz |
| M3 — Analiz ve ML bütünleşmesi | Kaynak hipotezleri; simülasyon verisinden öğrenen ön tahmin; kısıtlı aday arama; belirsizlik ve denetlenebilir rapor | Başarı iddiası ayrılmış testle sınırlı; sahadaki sinyallere komut verilmez |

M1/M2/M3 tarihler değildir. Belge 03'teki aşama etiketleri bu tanımlara işaret eder. Basit web arayüzü ve simülasyon adaptörü paralel geliştirilebilir; ML veri üretimi ise ağ, senaryo ve metrik sürümleri kararlı olmadan ölçeklendirilmez.

## 3. İş paketleri ve bağımlılıklar
| Paket | Somut çıktı | Bağımlılık / sorumlu rol |
|---|---|---|
| W01 Pilot ve veri | Sınır, mevcut ağ gözlemi, kaynak envanteri, izin/erişim durumu | Başlangıç; ürün sorumlusu + ulaşım/veri sorumlusu |
| W02 Referans model | Doğrulanmış ağ, sinyal/talep girdileri, çıktı adaptörü ve kalibrasyon kaydı | W01; modelleme sorumlusu |
| W03 Tasarım şablonları | Parametre/kısıt şeması, ilk operasyonel ve fiziksel alternatif, ağ derleyici | W02 temel şeması; backend + modelleme |
| W04 Deney altyapısı | İş kuyruğu, manifest, tekrarlar, metrikler ve karşılaştırma | W02; backend + doğrulama |
| W05 Öğrenme ve aday arama | Veri seti sürümü, basit referans, grup ayrımlı test ve ön eleme modeli | W03/W04 kararlı çıktıları; ML sorumlusu |
| W06 Web ve 3D | 2D ağ, proje/senaryo akışı, FCD tekrarı, sonuç durumu | W02 veri sözleşmesi; arayüz/3D sorumlusu |
| W07 Maliyet ve rapor | Metraj hesabı, fiyat kataloğu, bütçe filtresi ve kaynaklı rapor | W03/W04; backend + ürün doğrulama |
| W08 Bütünleşik sınama | Deney matrisi, kullanıcı görevi, kaynak/izin kontrolü ve teslim paketi | W03–W07; ekip içi bağımsız gözden geçiren |

W01'de gerekli verilerin edinilememesi, diğer işlerin sentetik örnekle teknik ilerlemesini engellemez. Ancak bu durumda gerçek pilot için doğrulama tamamlanmış yazılamaz. Hipotez modülü W04'ün zaman serileriyle geliştirilebilir; ML'den bağımsız bir ilk kural sürümü mümkündür.

## 4. Aşama geçiş kapıları
**G0 — Problem/veri:** Kullanıcı rolü, pilot adayı, müdahale sınırı ve veri erişim statüsü kayıtlı. Eksik girdiler için plan veya açık varsayım var.

**G1 — Referans:** Ağ teknik denetimden geçti; talep ve kontrol kaynağı belli; gözlem varsa ayrı doğrulama planı var. Teknik çalışabilirlik ve saha geçerliliği ayrı durumlar.

**G2 — Karşılaştırma:** En az bir işletim ve bir fiziksel düzenleme uygun protokolle çalıştırılabiliyor. Bitmeyen yolculuklar ve yan kol etkileri saklanmıyor. 3D doğru ağ sürümünü gösteriyor.

**G3 — Analiz/ML:** Hipotezin dayanağı görülebiliyor; yetersiz veri sonucu var. ML karşılaştırma modelleri ve ayrılmış test kayıtları mevcut. Fayda göstermeyen ML bileşeni zorunlu öneri motoru yapılmıyor; neden ve sonraki deney planı raporlanıyor.

**G4 — Teslim:** Gereksinim–bileşen–test bağlantıları, kaynaklar, lisanslar, açık eksikler ve tekrar üretme yönergesi tamam. Gözleme dayanmayan ürün demosu açıkça etiketli.

## 5. Risk ve alternatif plan kaydı
| Risk | Erken işaret / tetikleyici | Yanıt ve sınır |
|---|---|---|
| RİSK-01 Veri erişilemez | Sinyal/sayım verisi için somut örnek alınamıyor. | Pilot daraltılır veya izinli saha sayımı planlanır; sentetik çalışma gerçek doğrulama diye sunulmaz. |
| RİSK-02 Model uyumsuz | Kuyruk yeri, zamanlaması veya akış ayrı gözlemde açıklanamıyor. | Geometri, kontrol, talep sırayla denetlenir; model geçerliliği sınırlanır. |
| RİSK-03 Geometri uygulanamaz | Yol genişliği, bağlantı veya yaya alanı sınırı ihlal ediliyor. | Aday reddedilir/uzman incelemesine alınır; simülasyon başarısı izin yerine geçmez. |
| RİSK-04 Kapsam büyür | Her özellik yeni bir motor, veri veya şehir ölçeği istiyor. | M1 uçtan uca akışı korunur; değişiklik FR ve plan kaydıyla onaylanır. |
| RİSK-05 3D yavaşlar | Hedef cihazda kare süresi/bellek kabul aralığı dışına çıkıyor. | Tekrarda örnekleme ve görüntü ayrıntısı ayarlanır; fizik adımı değiştirilmez. |
| RİSK-06 ML genellenmez | Yeni tasarım ailesinde hata veya yan etki kaçırma artıyor. | OOD işareti ve doğrudan simülasyon yolu; daha fazla temsil/veri, daha dar çalışma alanı. |
| RİSK-07 Veri sızıntısı | Aynı tasarımın tekrarları iki veri bölümünde görülüyor. | Grup ayrımı ve veri seti manifesti otomatik denetlenir; test yeniden ayrılır. |
| RİSK-08 Yanlı başarı | Ağa giremeyenler veya bitmeyenler artarken ortalama iyileşiyor. | Sunulan talep, tamamlanma ve artık kuyruk zorunlu rapor alanı yapılır. |
| RİSK-09 Fiyatlar eksik | Birim, tarih, kapsam veya temel fiyat kaynağı yok. | “Maliyet eksik / bütçe uygunluğu belirsiz” durumu; eksik kalem sıfır sayılmaz. |
| RİSK-10 Lisans/erişim belirsiz | Harita, video veya 3D varlık kullanım şartı kayıtsız. | Kaynak envanteri ve kurum/uzman kontrolü; izin netleşmeden dağıtım yok. |
| RİSK-11 Deney pahalı | Simülasyon/trajectory boyutu hedef kaynakları aşıyor. | Küçük kaynak profili, arşivleme ve seçili adayların ayrıntılı tekrarı; kör ölçekleme yok. |
| RİSK-12 Teknik bağımlılık | Bir kişinin modülü olmadan bütün akış duruyor. | Sözleşme, örnek girdi/çıktı ve tekrar yönergesi; ikinci kişiyle kurulum denemesi. |

Bunlar nitel yönetim kayıtlarıdır; olasılık ve etki puanları ölçülmüş gibi verilmemiştir. Her risk için sahip rolü ve gözden geçirme tarihi ekip tarafından eklenecektir.

## 6. Kaynak ve bütçe oluşturma yöntemi
İlk bütçe kalemleri veri edinme/saha çalışması, hesaplama, depolama, harita/3D varlık kullanımı ve gerekiyorsa uzman doğrulamasıdır. Çalışma bilgisayarı veya GPU alımı otomatik varsayılmaz. Önce küçük sayıda referans koşuda CPU süresi, en yüksek bellek, çıktı dosyası büyüklüğü ve 3D tekrar performansı ölçülür; sonra aylık/deney başı kaynak senaryosu çıkarılır.

Altyapı bütçesi ile kullanıcıya sunulan yol müdahalesi maliyeti ayrı kayıtlardır. KGM ve YFK kaynakları olası katalog başlangıçlarıdır; bu pakette güncel poz eşlemesi, miktar keşfi veya teklif alınmış değildir. Veri hizmetleri için fiyat ve lisans koşulları satın alma öncesinde yeniden kontrol edilir. [R33] [R34]

## 7. İlk geliştirme iş listesi
| İş | Teslim edilecek kanıt | Bağlantı |
|---|---|---|
| B01 Kapsam toplantısı | Pilot adayları, kullanıcı rolü ve açık kararların kaydı | Belge 01 / G0 |
| B02 Örnek veri denetimi | Geometri, sinyal ve sayım için birer örnek; erişim statüsü | Belge 04 / EK-01 |
| B03 Küçük referans ağ | Ağ, talep, kontrol dosyaları ve çalıştırma yönergesi | FR-03/05/15 |
| B04 Çıktı sözleşmesi | Metrik JSON'u, FCD örneği ve bitmeyen araç kaydı | FR-17/19/28 |
| B05 İki müdahale ailesi | Bir sinyal ve bir fiziksel şablonun kısıtlı üretimi | FR-09/16/21 |
| B06 Deney manifesti | Aynı girdiyi yeniden çalıştırma ve yanlış karşılaştırma negatif testi | EK-07/11 |
| B07 Dikey kullanıcı akışı | Bölge → aday → koşu → karşılaştırma; sade 3D dahil | FR-01/27/33 |
| B08 Metraj/fiyat prototipi | Bilinen örnekte el hesabıyla uyum, eksik fiyat testi | FR-23–26 |
| B09 Hipotez prototipi | Kuyruk taşması, alternatif açıklama ve yetersiz veri örneği | EK-04/05 |
| B10 ML deney hazırlığı | Gruplama planı, basit karşılaştırma, ayrılmış test manifesti | FR-19/20 |

Bu işler kullanıcı adına bir platforma atanmış değildir; planlanan backlog'dur. Gerçek çalışma süresi ve sorumlular belirlendiğinde iş takip aracına aktarılabilir.

## 8. Açık kararlar
| Kimlik | Karar | Kapanması için gereken bilgi |
|---|---|---|
| O01 | Pilotun kesin sınırı | Ankara adayları, veri ve müdahaleden etkilenen ağ |
| O02 | Veri edinme yolu | Sayım/sinyal örneği, erişim ve kullanım izni |
| O03 | İlk fiziksel şablon | Ulaşım uzmanı değerlendirmesi ve geometri sınırları |
| O04 | Ekip ve takvim | Kişiler, yetkinlikler, haftalık kapasite, teslim tarihi |
| O05 | Başarı ve yan etki eşikleri | Pilot değişkenliği, kullanıcı önceliği ve ön kayıt |
| O06 | Yaya/bisiklet/otobüs davranış kapsamı | Talep ve hizmet verisi; geometri ile davranış ayrımı |
| O07 | Maliyet kataloğu | Poz, tarih, birim, vergi/iş kapsamı ve sorumlu |
| O08 | Teknoloji ve sürümler | Küçük teknik deneme, lisans ve dağıtım kısıtı |
| O09 | Kısa vadeli talep tahmini | Yeterli zaman serisi ve kullanıcı ihtiyacı |
| O10 | Test ve saha uzmanı | Teknik model/kısıt incelemesi yapacak kişi/kurum |

## 9. Teslim ve akademik raporlama
Belge 01 amaç ve kapsamı; Belge 02 literatür ve gerekçeli teknik seçimi; Belge 03 gereksinimleri; Belge 04 veri yöntemini; Belge 05 analitik yaklaşımı; Belge 06 mimariyi; Belge 07 deney tasarımını; bu belge iş paketleri ve riskleri besler. Sunum ve araştırma önerisi bu ortak kaynaklardan türetilmelidir.

Bu paket, doldurulup gönderilmiş bir TÜBİTAK başvurusu, imzalanmış danışman onayı veya saha uygulama projesi değildir. Takımın araştırma ve geliştirme kararlarını üzerinde verebileceği, kaynaklı ilk tasarım sürümüdür. İlk karar oturumunun somut hedefi O01–O04'ü kapatmak ve B02 için erişilebilir örnek veriyi belirlemektir.

## Kaynak bağlantıları

[R33]: https://www.kgm.gov.tr/Sayfalar/KGM/SiteTr/Duyurular/DuyuruDetay.aspx?Parameter=2014
[R34]: https://yfk.csb.gov.tr/aylik-guncel-rayic-ve-birim-fiyat-listeleri-113351
