# TrafficML — Araştırma ve Tasarım Paketi

**Tarih:** 02 Ekim 2026  
**Sürüm:** 0.1 — Ekip değerlendirmesine açık araştırma/tasarım taslağı

## Başlangıç

`TrafficML_Arastirma_ve_Tasarim_v0.1.pdf` bütün paketin 40 sayfalık okuma sürümüdür. İlk iki sayfa özet ve belge haritasıdır; 8 ana rapor PDF yer imleriyle açılabilir. Altlıklardaki numaralar belge içi sayfa numaralarıdır.

## Dosya yapısı

- `docx/`: 8 ana rapor ve özetin düzenlenebilir Word dosyaları.
- `pdf/`: Her belgenin ayrı okuma sürümü.
- `markdown/`: Aynı raporların metin kaynakları. Düzenlemede Word ile Markdown arasında hangi sürümün esas olduğuna ekip karar vermelidir.
- `ekler/kaynak_katalogu.json`: 36 dış kaynağın künyesi, adresi, inceleme düzeyi ve proje açısından notları.
- `ekler/gereksinim_izlenebilirlik.json` ve `.md`: Özgün 37 FR için kabul, bileşen, aşama ve test bağlantıları. EK/NF maddeleri Belge 03 içindedir.
- `ekler/sistem_mimarisi.mmd`: Önerilen bileşen akışı, Mermaid metin kaynağı.
- `ekler/senaryo_calistirma.mmd`: Senaryo çalıştırma sıralaması, Mermaid metin kaynağı.
- `ekler/veri_modeli.mmd`: Önerilen kavramsal veri ilişkileri, Mermaid metin kaynağı; yürütülebilir veritabanı şeması değildir.
- `ekler/arastirma_sinirlari.md`: Araştırma ve doğrulama sınırlarının kısa kaydı.

## Kaynaklar ve kapsam

K01: Kullanıcının `Kentsel_Ulasim_FR_Listesi.pdf` (37 FR, v1.0, 01.10.2026). K02: `TrafficML_Proje_Fikri_ve_On_Arastirma_Raporu.md` (v0.1, 01.10.2026). K03: Kullanıcının gönderdiği konsept arayüz. Bunların kapsam farkları Belge 01 içinde açıkça belirtilmiştir. Özgün kaynak belgeler bu pakette değiştirilmemiştir; kaynak metni ile yeni kabul koşulları Belge 03’te ayrılmıştır.

R01–R36 dış kaynakları araştırma raporunda açıklamalıdır. Üretici açıklaması bağımsız performans kıyaslaması değildir; özet düzeyinde incelenen araştırmalar ve erişimi sınırlı sayfalar katalogda işaretlidir. Bu çalışma sistematik literatür taraması, pazarın eksiksiz envanteri veya patent yenilik araştırması değildir.

## Ne yapılmadı?

Kodlanmış ürün, çalışan simülasyon, eğitilmiş ML modeli, elde edilmiş kurum/saha verisi veya ölçülmüş iyileşme teslim edilmiyor. Dokümanlarda deneyler ve kabul testleri plan durumundadır. Maliyet keşfi veya satın alma fiyatı üretilmemiştir. Veri talebi metni taslaktır, gönderilmemiştir.

Pilot, ekip, teslim tarihi ve bütçe kesinleşmemiştir. Kaza ve kaza-risk analizi kapsam dışıdır. İlk prototipte hem sinyal hem fiziksel düzenleme ve sade 3D akışı önerilmektedir; sınırsız otomatik yol tasarımı taahhüt edilmez.

## Güncelleme

Her değişiklikte kaynak gereksinimi ile öneri ayrımını koruyun. Kararlar için Belge 08’in O01–O10 kayıtlarını, kabul ve test bağlantıları için Belge 03’ü güncelleyin. Simülasyon sonucunu yayımlamadan önce Belge 07 protokolüne göre veri/model/talep/senaryo sürümlerini kaydedin. Bu belge sürümünün tarihi, dış kaynakların sonsuza kadar güncel kalacağını ifade etmez.
