# Gereksinim–bileşen–test izlenebilirliği

37 özgün FR korunmuştur. Kabul ölçütleri öneridir; bütün testler planlandı / çalıştırılmadı durumundadır. EK ve NF ekleri Belge 03 içinde ayrıca tanımlıdır.

| FR | Kaynak başlığı | Modül | Aşama | Test |
|---|---|---|---|---|
| FR-01 | Proje Oluşturma | PROJECT | M1 | T-FR-01 |
| FR-02 | Analiz Bölgesi Seçimi | PROJECT | M1 | T-FR-02 |
| FR-03 | Mevcut Yol Verisinin Alınması | PROJECT | M1 | T-FR-03 |
| FR-04 | Yol Parametrelerinin Düzenlenmesi | PROJECT | M1 | T-FR-04 |
| FR-05 | Trafik Yoğunluğu Girişi | DATA | M1 | T-FR-05 |
| FR-06 | Trafik Dağılımı Tanımlama | DATA | M1 | T-FR-06 |
| FR-07 | Araç Türlerinin Tanımlanması | DATA | M1 | T-FR-07 |
| FR-08 | Farklı Trafik Senaryoları | DATA | M1 | T-FR-08 |
| FR-09 | Alternatif Yol Tasarımı Oluşturma | DESIGN | M1/M2 | T-FR-09 |
| FR-10 | Refüj Ekleme | DESIGN | M2 | T-FR-10 |
| FR-11 | Ağaçlandırma | DESIGN | M2 | T-FR-11 |
| FR-12 | Bisiklet Yolu | DESIGN | M2 | T-FR-12 |
| FR-13 | Yaya Altyapısı | DESIGN | M2 | T-FR-13 |
| FR-14 | Toplu Taşıma Düzenlemeleri | DESIGN | M2 | T-FR-14 |
| FR-15 | Trafik Simülasyonu Çalıştırma | SIM | M1 | T-FR-15 |
| FR-16 | Alternatif Tasarımların Simülasyonu | SIM | M1 | T-FR-16 |
| FR-17 | Trafik Performans Metrikleri | SIM | M1 | T-FR-17 |
| FR-18 | Farklı Zaman/Yoğunluk Koşulları | SIM | M1 | T-FR-18 |
| FR-19 | Simülasyon Verisi Toplama | ML | M1 | T-FR-19 |
| FR-20 | Performans Tahmini | ML | M3 | T-FR-20 |
| FR-21 | Tasarım Alternatifleri Üretme/Seçme | OPT | M3 | T-FR-21 |
| FR-22 | Optimizasyon | OPT | M3 | T-FR-22 |
| FR-23 | Birim Maliyet Yönetimi | COST | M2 | T-FR-23 |
| FR-24 | Tahmini Proje Maliyeti | COST | M2 | T-FR-24 |
| FR-25 | Bütçe Tanımlama | COST | M2 | T-FR-25 |
| FR-26 | Bütçeye Göre Alternatif Filtreleme | COST | M2 | T-FR-26 |
| FR-27 | 3D Yol Görselleştirme | VIEW3D | M1 | T-FR-27 |
| FR-28 | 3D Trafik Animasyonu | VIEW3D | M1 | T-FR-28 |
| FR-29 | Belediye Elemanlarının Görselleştirilmesi | VIEW3D | M2 | T-FR-29 |
| FR-30 | Kamera Kontrolü | VIEW3D | M1 | T-FR-30 |
| FR-31 | Simülasyon Kontrolü | VIEW3D | M1 | T-FR-31 |
| FR-32 | Tasarım Değişikliklerinin Görselleştirilmesi | VIEW3D | M1 | T-FR-32 |
| FR-33 | Senaryo Karşılaştırması | REPORT | M1 | T-FR-33 |
| FR-34 | Performans Karşılaştırması | REPORT | M1 | T-FR-34 |
| FR-35 | Maliyet/Performans Karşılaştırması | REPORT | M2 | T-FR-35 |
| FR-36 | Çevresel/Kentsel Göstergeler | REPORT | M2 | T-FR-36 |
| FR-37 | Sonuç Raporu | REPORT | M1/M3 | T-FR-37 |
